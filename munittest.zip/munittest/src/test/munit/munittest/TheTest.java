/**
 * 
 */
package munittest;

import org.junit.Test;
import org.mule.munit.common.mocking.Attribute;
import org.mule.munit.runner.functional.FunctionalMunitSuite;

/**
 * @author Upesh
 *
 */
public class TheTest extends FunctionalMunitSuite {

	  @Test
	  public void test() {
	    Attribute attribute = Attribute.attribute("name").
	      ofNamespace("doc").withValue("Real Set Payload"); 

	    verifyCallOfMessageProcessor("set-payload") 
	    .ofNamespace("mule")                        
	    .withAttributes(attribute)                  
	    .times(1);                                  

	  }
	}