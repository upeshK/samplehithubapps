/**
 * 
 */
package com.ebuilder.shipment.validation;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.ebuilder.ebtransport.ubleb.despatchadvice.DespatchAdviceType;
import com.ebuilder.shipment.validation.dto.CarrierResponseDTO;
import com.ebuilder.shipment.validation.dto.ExceptionDTO;
import com.ups.ship.ShipmentRequest;

/**
 * @author upesh
 *
 */
public abstract class AbstractValidator {

	// next element in chain
	protected AbstractValidator next;
	protected List<ExceptionDTO> exceptionHolder = new ArrayList<ExceptionDTO>();
	protected String failedReasonID;
	private static final Logger LOG = Logger.getLogger(AbstractValidator.class);

	public void next(AbstractValidator next) {
		this.next = next;
	}

	public CarrierResponseDTO validate(DespatchAdviceType despatchAdviceType, ShipmentRequest shipRequest, CarrierResponseDTO response) {
		LOG.info("Request Validation Chain Started");
		if (!hasErrors()) {
			populate(despatchAdviceType, shipRequest);
			if (next != null) {
				response = next.validate(despatchAdviceType, shipRequest, response);
			}
		} else {

			response.setExceptionDTOList(exceptionHolder);
			// message.setFailed(Constants.MESSAGE_FAILED);
			response.setFailedReasonID(failedReasonID);
		}
		return response;
	}

	public boolean hasErrors() {
		return !exceptionHolder.isEmpty();
	}

	public List<ExceptionDTO> getExceptionHolder() {
		return exceptionHolder;
	}

	public abstract void populate(DespatchAdviceType despatchAdviceType, ShipmentRequest shipRequest);

}
