/**
 * 
 */
package com.ebuilder.shipment.validation;

import com.ebuilder.ebtransport.ubleb.despatchadvice.DespatchAdviceType;
import com.ebuilder.shipment.dto.ValidationResultDTO;

/**
 * @author upesh
 *
 */
public class UPSWSRequestValidator {

	ValidationResultDTO result;
	IValidationRule rule;

	public void setRule(IValidationRule rule) {
		this.rule = rule;
	}

	public ValidationResultDTO validate(DespatchAdviceType despatchAdviceType) {
		result=rule.validate(despatchAdviceType);
		return this.result;
	}
}