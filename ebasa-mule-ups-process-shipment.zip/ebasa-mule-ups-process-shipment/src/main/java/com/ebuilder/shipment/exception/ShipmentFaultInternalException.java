/**
 * 
 */
package com.ebuilder.shipment.exception;

import org.mule.config.i18n.Message;
import org.mule.transformer.AbstractTransformer;

/**
 * @author upesh
 *
 */
public class ShipmentFaultInternalException extends ShipmentFaultException {
	
	private static final long serialVersionUID = 309638070759167775L;

	public ShipmentFaultInternalException(Message message, Throwable cause) {
		super(message, cause);
	}

	public ShipmentFaultInternalException(Message message, AbstractTransformer transformer) {
		super(message, transformer);
	}

	
	

}
