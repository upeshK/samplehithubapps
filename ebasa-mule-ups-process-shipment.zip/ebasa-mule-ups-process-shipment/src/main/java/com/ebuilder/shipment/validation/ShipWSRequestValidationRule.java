/**
 * 
 */
package com.ebuilder.shipment.validation;

import java.util.ArrayList;
import java.util.List;

import com.ebuilder.ebtransport.ubleb.despatchadvice.AddressType;
import com.ebuilder.ebtransport.ubleb.despatchadvice.CustomerPartyType;
import com.ebuilder.ebtransport.ubleb.despatchadvice.DespatchAdviceType;
import com.ebuilder.ebtransport.ubleb.despatchadvice.GoodsItemType;
import com.ebuilder.ebtransport.ubleb.despatchadvice.PartyType;
import com.ebuilder.shipment.dto.ExceptionDTO;
import com.ebuilder.shipment.dto.ValidationResultDTO;
import com.ebuilder.util.Constants;
import com.ebuilder.util.StringUtils;

/**
 * @author upesh
 *
 */
public class ShipWSRequestValidationRule implements IValidationRule {


	@Override
	public ValidationResultDTO validate(final DespatchAdviceType despatchAdvice) {

		final List<ExceptionDTO> exceptionDTOs=new ArrayList<ExceptionDTO>();
		final ValidationResultDTO validationDTO = new ValidationResultDTO();	

		//Shipper Validation	
		if (StringUtils.isNotEmpty(despatchAdvice.getBillingParty()) 
				&& despatchAdvice.getBillingParty().equals(Constants.BillingParty.BILL_SHIPPER.getName())
				&& despatchAdvice.getOriginatorCustomerParty() != null ) {			
			final CustomerPartyType shipperPartyType = despatchAdvice.getOriginatorCustomerParty();			
			validateShipper(shipperPartyType, despatchAdvice,exceptionDTOs);	

		}

		if (StringUtils.isNotEmpty(despatchAdvice.getBillingParty()) 
				&& despatchAdvice.getBillingParty().equals(Constants.BillingParty.BILL_RECEIVER.getName())
				&& despatchAdvice.getDeliveryCustomerParty() != null){			
			final CustomerPartyType shipperPartyType = despatchAdvice.getDeliveryCustomerParty();			
			validateShipper(shipperPartyType, despatchAdvice,exceptionDTOs);	

		}


		if (StringUtils.isNotEmpty(despatchAdvice.getBillingParty()) && 
				despatchAdvice.getBillingParty().equals(Constants.BillingParty.BILL_THIRD_PARTY.getName())
				&& despatchAdvice.getBillingThirdParty() != null){			
			final CustomerPartyType shipperPartyType = despatchAdvice.getBillingThirdParty();			
			validateShipper(shipperPartyType, despatchAdvice,exceptionDTOs);	

		}

		//ShipTo Validation
		if (despatchAdvice.getDeliveryCustomerParty() != null) {
			validateParty(Constants.SHIP_TO_CONTEXT,despatchAdvice.getDeliveryCustomerParty(),exceptionDTOs);
		}

		//ShipFrom Validation
		if ((StringUtils.isNotEmpty(despatchAdvice.getBillingParty())) 
				&& ((despatchAdvice.getBillingParty().equals(Constants.BillingParty.BILL_RECEIVER.getName())) 
						|| (despatchAdvice.getBillingParty().equals(Constants.BillingParty.BILL_THIRD_PARTY.getName())))) {
			validateParty(Constants.SHIP_FROM_CONTEXT,despatchAdvice.getOriginatorCustomerParty(),exceptionDTOs);
		}

		//Service Validation
		if (despatchAdvice.getDespatchLine() != null 
				&& !despatchAdvice.getDespatchLine().isEmpty() 
				&& despatchAdvice.getDespatchLine().get(0).getShipment() != null 
				&& StringUtils.isEmpty(despatchAdvice.getDespatchLine().get(0).getShipment().getShippingPriorityLevelCode())) {
			exceptionDTOs.add(new ExceptionDTO("Carrier Service Missing"));
		}

		//package weight validation
		if (despatchAdvice.getDespatchLine() != null 
				&& !despatchAdvice.getDespatchLine().isEmpty() 
				&& despatchAdvice.getDespatchLine().get(0).getShipment() != null 
				&& despatchAdvice.getDespatchLine().get(0).getShipment().getGoodsItem() != null) {
			final List<GoodsItemType> goodsItemTypes = despatchAdvice.getDespatchLine().get(0).getShipment().getGoodsItem();
			for (GoodsItemType goodsItemType : goodsItemTypes) {
				if (StringUtils.isEmpty(goodsItemType.getGrossWeightMeasure())) {
					exceptionDTOs.add(new ExceptionDTO("Package Weight Missing"));
				}
				else if(StringUtils.isNumber(goodsItemType.getGrossWeightMeasure())){
					try{					
						if((Double.parseDouble(goodsItemType.getGrossWeightMeasure()))<(Constants.UPS_DEFAULT_WAIGHT)){
							goodsItemType.setGrossWeightMeasure(Constants.STR_UPS_DEFAULT_WAIGHT);
						}
					}
					catch(NumberFormatException e){

					}
				}
			}
		}
		if (exceptionDTOs != null && exceptionDTOs.isEmpty()) {
			validationDTO.setStatus(Constants.SUCCESS_RESPONSE);
		} 
		if (exceptionDTOs != null && !exceptionDTOs.isEmpty()) {
			validationDTO.setStatus(Constants.FAILURE_RESPONSE);
		}
		validationDTO.setExceptionDTOs(exceptionDTOs);
		return validationDTO;
	}

	private void validateShipper(final CustomerPartyType shipperPartyType,final DespatchAdviceType despatchAdvice,final List<ExceptionDTO> exceptionDTOs) {


		if(despatchAdvice.getDespatchSupplierParty()!=null 
				&& StringUtils.isEmpty(despatchAdvice.getDespatchSupplierParty().getCustomerAssignedAccountID())){
			exceptionDTOs.add(new ExceptionDTO("Shipper Number Missing"));
		}

		if(despatchAdvice.getDespatchSupplierParty()!=null 
				&& StringUtils.isNotEmpty(despatchAdvice.getDespatchSupplierParty().getCustomerAssignedAccountID())
				&& despatchAdvice.getDespatchSupplierParty().getCustomerAssignedAccountID().length()!=6){
			exceptionDTOs.add(new ExceptionDTO("Invalid Length for Shipper Number"));
		}

		if (shipperPartyType.getParty() != null) {
			final PartyType partyType = shipperPartyType.getParty();
			if (StringUtils.isEmpty(partyType.getPartyName())) {
				exceptionDTOs.add(new ExceptionDTO("Shipper Name Missing"));
			}
			else if(partyType.getPartyName().length()>35){
				String shipperName=partyType.getPartyName().substring(0,35);
				partyType.setPartyName(shipperName);
			}

			if (partyType.getPostalAddress() != null) {
				final AddressType shipperAddr=partyType.getPostalAddress();				
				validateAddress(Constants.SHIPPER_CONTEXT,shipperAddr,exceptionDTOs);

				if (shipperPartyType.getDeliveryContact() != null) {
                    String siteID = partyType.getPartyID();
                    String personName = partyType.getPerson();

                    // Person name must be used as contact name for consumer sites.
                    //TO check
                    if (StringUtils.isNotEmpty(personName) /*&& CarrierConnectorHelper.getInstance().isConsumer(siteID)*/) {
                        shipperPartyType.getDeliveryContact().setName(personName);
                    }
                }

				if ( StringUtils.isNotEmpty(shipperAddr.getCountry()) 
						&& despatchAdvice.getDeliveryCustomerParty() != null 
						&& despatchAdvice.getDeliveryCustomerParty().getParty()!= null 
						&& despatchAdvice.getDeliveryCustomerParty().getParty().getPostalAddress()!=null
						&& despatchAdvice.getDeliveryCustomerParty().getParty().getPostalAddress().getCountry()!=null
						&& StringUtils.isNotEmpty(despatchAdvice.getDeliveryCustomerParty().getParty().getPostalAddress().getCountry().getIdentificationCode())
						&& shipperAddr!=null 
						&& shipperAddr.getCountry()!=null
						&& StringUtils.isNotEmpty(shipperAddr.getCountry().getIdentificationCode())
						&& (!shipperAddr.getCountry().getIdentificationCode().equals(despatchAdvice.getDeliveryCustomerParty().getParty().getPostalAddress().getCountry().getIdentificationCode()))						
						&& shipperPartyType.getDeliveryContact() != null && StringUtils.isEmpty(shipperPartyType.getDeliveryContact().getName()))
				{
					exceptionDTOs.add(new ExceptionDTO("Shipper Attention Name missing for International Shipment"));

				}			
			}
		}
	}



	private void validateParty(final String context,final CustomerPartyType deliveryPartyType,final List<ExceptionDTO> exceptionDTOs) {
		if (deliveryPartyType.getParty() != null) {

			final PartyType partyType = deliveryPartyType.getParty();
			if (StringUtils.isEmpty(partyType.getPartyName())) {
				exceptionDTOs.add(new ExceptionDTO(context,"Name Missing"));
			}
			else if(partyType.getPartyName().length()>35){
				String partyName=partyType.getPartyName().substring(0,35);
				partyType.setPartyName(partyName);
			}
			if (partyType.getPostalAddress() != null) {
				validateAddress(context,partyType.getPostalAddress(),exceptionDTOs);
			}

		}


	}


	private void validateAddress(final String context,final AddressType addressType,final List<ExceptionDTO> exceptionDTOs) {

		if (addressType != null) {


			if(StringUtils.isEmpty(addressType.getStreetName())){
				exceptionDTOs.add(new ExceptionDTO(context,"Address Missing"));
			}
			else if(addressType.getStreetName().length()>35){
				String addressLine=addressType.getStreetName().substring(0,35);
				addressType.setStreetName(addressLine);
			}
			if (StringUtils.isEmpty(addressType.getCityName())) {
				exceptionDTOs.add(new ExceptionDTO(context,"City Missing"));
			}
			else if(addressType.getCityName().length()>30){
				String city=addressType.getCityName().substring(0,30);
				addressType.setCityName(city);
			}

			if (addressType.getCountry() != null 
					&& addressType.getCountry().getIdentificationCode() != null 
					&& ((addressType.getCountry().getIdentificationCode().equals("US")) 
							|| (addressType.getCountry().getIdentificationCode().equals("CA")) 
							|| (addressType.getCountry().getIdentificationCode().equals("PR")))
							&&  (StringUtils.isEmpty(addressType.getPostalZone()))) {
				exceptionDTOs.add(new ExceptionDTO(context,"Postal Code Missing For CA/US/PR"));

			}

			if(StringUtils.isNotEmpty(addressType.getPostalZone()) && addressType.getPostalZone().length()>9 ){
				String postalZone= addressType.getPostalZone().substring(0,9);
				addressType.setPostalZone(postalZone);
			}

			if (addressType.getCountry() != null 
					&& addressType.getCountry().getIdentificationCode() != null 
					&& ((addressType.getCountry().getIdentificationCode().equals("US")) 
							|| (addressType.getCountry().getIdentificationCode().equals("CA"))) 
							&& (StringUtils.isEmpty(addressType.getRegion()))) {
				exceptionDTOs.add(new ExceptionDTO(context,"State/Province Missing For US/CA"));
			}

			if (addressType.getCountry() != null 
					&& StringUtils.isEmpty(addressType.getCountry().getIdentificationCode())) {
				exceptionDTOs.add(new ExceptionDTO(context,"Country Code Missing"));
			}

		}
	}




}

