/**
 * 
 */
package com.ebuilder.shipment.validation;

import java.util.List;

import org.apache.log4j.Logger;

import com.ebuilder.ebtransport.ubleb.despatchadvice.AddressType;
import com.ebuilder.ebtransport.ubleb.despatchadvice.ContactType;
import com.ebuilder.ebtransport.ubleb.despatchadvice.CustomerPartyType;
import com.ebuilder.ebtransport.ubleb.despatchadvice.DespatchAdviceType;
import com.ebuilder.ebtransport.ubleb.despatchadvice.PartyType;
import com.ebuilder.shipment.validation.dto.CarrierResponseDTO;
import com.ebuilder.shipment.validation.dto.ExceptionDTO;
import com.ebuilder.util.Constants;
import com.ebuilder.util.StringUtils;
import com.ups.ship.ShipPhoneType;
import com.ups.ship.ShipToAddressType;
import com.ups.ship.ShipToType;
import com.ups.ship.ShipmentRequest;
import com.ups.ship.ShipmentType;

/**
 * @author upesh
 *
 */
public class ShipToPartyTypeValidator extends AbstractValidator {

	private static final Logger LOG = Logger.getLogger(ShipToPartyTypeValidator.class);

	public CarrierResponseDTO validate(DespatchAdviceType despatchAdvice, ShipmentRequest shipRequest, CarrierResponseDTO response) {
		LOG.info("ShipTo Party Validation Started");
		if (despatchAdvice.getDeliveryCustomerParty() != null) {
			validateParty(Constants.SHIP_TO_CONTEXT, despatchAdvice.getDeliveryCustomerParty());
		}
		return super.validate(despatchAdvice, shipRequest, response);
	}

	@Override
	public void populate(DespatchAdviceType despatchAdviceType, ShipmentRequest shipRequest) {
		if (despatchAdviceType.getDeliveryCustomerParty() != null) {
			setShipTo(despatchAdviceType.getDeliveryCustomerParty(), shipRequest.getShipment());
		}

	}

	private void setShipTo(final CustomerPartyType deliveryPartyType, final ShipmentType shipmentType) {
		if (deliveryPartyType != null && deliveryPartyType.getParty() != null) {
			PartyType partyType = deliveryPartyType.getParty();
			boolean consumerFlag = (partyType != null ? (partyType.getContact() != null ? (partyType.getContact().getNote() != null ? partyType
					.getContact().getNote().equalsIgnoreCase("Consumer")
					: false)
					: false)
					: false);
			final ShipToType shipTo = new ShipToType();

			if (deliveryPartyType.getParty().getPostalAddress() != null) {
				final com.ebuilder.ebtransport.ubleb.despatchadvice.AddressType delAddressType = deliveryPartyType.getParty()
						.getPostalAddress();
				shipTo.setName(deliveryPartyType.getParty().getPartyName());

				if (deliveryPartyType.getDeliveryContact() != null
						&& StringUtils.isNotEmpty(deliveryPartyType.getDeliveryContact().getName())) {
					shipTo.setAttentionName(deliveryPartyType.getDeliveryContact().getName());
				}

				String personName = deliveryPartyType.getParty().getPerson();
				// TODO
				if (StringUtils.isNotEmpty(personName) && consumerFlag) {

					shipTo.setName(personName);
					shipTo.setAttentionName(personName);
				}

				final ShipToAddressType shipToAddress = new ShipToAddressType();

				final List<String> addrLineList = shipToAddress.getAddressLine();
				addrLineList.add(delAddressType.getStreetName());
				
				if(StringUtils.isNotEmpty(delAddressType.getAdditionalStreetName())){
					addrLineList.add(1,delAddressType.getAdditionalStreetName().length()>35?delAddressType.getAdditionalStreetName().substring(0, 35):delAddressType.getAdditionalStreetName());
				}
				
				if(delAddressType.getAddressLine()!=null && !delAddressType.getAddressLine().isEmpty()){
					String addressLine3=delAddressType.getAddressLine().get(0);
					addrLineList.add(addressLine3.length()>35?addressLine3.substring(0, 35):addressLine3);
				}

				shipToAddress.setCity(delAddressType.getCityName());

				if (StringUtils.isNotEmpty(delAddressType.getPostalZone())) {
					shipToAddress.setPostalCode(delAddressType.getPostalZone());
				}
				if (StringUtils.isNotEmpty(delAddressType.getRegion())) {
					shipToAddress.setStateProvinceCode(delAddressType.getRegion());
				}
				if (delAddressType.getCountry() != null && delAddressType.getCountry().getIdentificationCode() != null) {
					shipToAddress.setCountryCode(delAddressType.getCountry().getIdentificationCode());
				}
				shipTo.setAddress(shipToAddress);
			}
			String contactNo = getContactNo(deliveryPartyType.getParty());
			if (StringUtils.isNotEmpty(contactNo)) {
				ShipPhoneType shipToPhone = new ShipPhoneType();
				shipToPhone.setNumber(contactNo);
				shipTo.setPhone(shipToPhone);
			}
			shipmentType.setShipTo(shipTo);
		}
	}

	/**
	 * if party type is consumer then the highest priority given to other
	 * communication field because other communication field holds the mobile no
	 * of the consumer
	 * 
	 * @param partyType
	 * @return String
	 */
	private String getContactNo(final PartyType partyType) {
		String contactNo = null;
		boolean consumerFlag = (partyType != null ? (partyType.getContact() != null ? (partyType.getContact().getNote() != null ? partyType
				.getContact().getNote().equalsIgnoreCase("Consumer") : false) : false) : false);
		if (partyType.getContact() != null) {
			final ContactType contactType = partyType.getContact();
			if (StringUtils.isNotEmpty(contactType.getTelephone())) {
				contactNo = contactType.getTelephone();
			}
			// TODO
			if (/*
				 * CarrierConnectorHelper.getInstance().isConsumer(partyType.
				 * getPartyID()) &&
				 */consumerFlag && StringUtils.isNotEmpty(contactType.getOtherCommunication())) {
				contactNo = contactType.getOtherCommunication().get(0);
			}
		}
		return contactNo;
	}

	private void validateParty(final String context, final CustomerPartyType deliveryPartyType) {
		if (deliveryPartyType.getParty() != null) {

			final PartyType partyType = deliveryPartyType.getParty();
			if (StringUtils.isEmpty(partyType.getPartyName())) {
				getExceptionHolder().add(new ExceptionDTO(context, "Name Missing"));
			} else if (partyType.getPartyName().length() > 35) {
				String partyName = partyType.getPartyName().substring(0, 35);
				partyType.setPartyName(partyName);
			}
			if (partyType.getPostalAddress() != null) {
				validateAddress(context, partyType.getPostalAddress());
			}

		}
	}

	private void validateAddress(final String context, final AddressType addressType) {

		if (addressType != null) {

			if (StringUtils.isEmpty(addressType.getStreetName())) {
				getExceptionHolder().add(new ExceptionDTO(context, "Address Missing"));
			} else if (addressType.getStreetName().length() > 35) {
				String addressLine = addressType.getStreetName().substring(0, 35);
				addressType.setStreetName(addressLine);
			}
			if (StringUtils.isEmpty(addressType.getCityName())) {
				getExceptionHolder().add(new ExceptionDTO(context, "City Missing"));
			} else if (addressType.getCityName().length() > 30) {
				String city = addressType.getCityName().substring(0, 30);
				addressType.setCityName(city);
			}

			if (addressType.getCountry() != null
					&& addressType.getCountry().getIdentificationCode() != null
					&& ((addressType.getCountry().getIdentificationCode().equals("US"))
							|| (addressType.getCountry().getIdentificationCode().equals("CA")) || (addressType.getCountry()
							.getIdentificationCode().equals("PR"))) && (StringUtils.isEmpty(addressType.getPostalZone()))) {
				getExceptionHolder().add(new ExceptionDTO(context, "Postal Code Missing For CA/US/PR"));

			}

			if (StringUtils.isNotEmpty(addressType.getPostalZone()) && addressType.getPostalZone().length() > 9) {
				String postalZone = addressType.getPostalZone().substring(0, 9);
				addressType.setPostalZone(postalZone);
			}

			if (addressType.getCountry() != null
					&& addressType.getCountry().getIdentificationCode() != null
					&& ((addressType.getCountry().getIdentificationCode().equals("US")) || (addressType.getCountry()
							.getIdentificationCode().equals("CA"))) && (StringUtils.isEmpty(addressType.getRegion()))) {
				getExceptionHolder().add(new ExceptionDTO(context, "State/Province Missing For US/CA"));
			}

			if (addressType.getCountry() != null && StringUtils.isEmpty(addressType.getCountry().getIdentificationCode())) {
				getExceptionHolder().add(new ExceptionDTO(context, "Country Code Missing"));
			}

		}
	}

}
