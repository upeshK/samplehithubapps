/**
 * 
 */
package com.ebuilder.shipment.exception;

import java.util.List;

import org.mule.DefaultMuleMessage;
import org.mule.api.MuleEventContext;
import org.mule.api.MuleMessage;
import org.mule.api.transport.PropertyScope;





import com.ebuilder.commons.muleapi.exceptionmapper.http.HttpExceptionMapper;
import com.ebuilder.ebtransport.ubleb.despatchadvice.DespatchAdviceType;
import com.ebuilder.ebtransport.ubleb.despatchadvice.DespatchLineType;
import com.ebuilder.ebtransport.ubleb.despatchadvice.DocumentType;
import com.ebuilder.ebtransport.ubleb.despatchadvice.ParamsType;
import com.ebuilder.ebtransport.ubleb.despatchadvice.ShippingDocsType;

/**
 * @author upesh
 *
 */
public class CustomExceptionMapper extends HttpExceptionMapper {
	
	private static final String DESPATCH_REQ = "despatchReq";
	
	@Override
	public Object onCall(MuleEventContext eventContext) throws Exception {
		
		
		MuleMessage message=(DefaultMuleMessage) super.handleException(eventContext, getInheritedFormatter());
		ParamsType paramsType=null;
		if(message.getPayload() instanceof ParamsType){
			 paramsType=(ParamsType)message.getPayload();			
		} ;
		DespatchAdviceType despatchAdvice=(DespatchAdviceType)message.getProperty(DESPATCH_REQ, PropertyScope.SESSION);
		
		if(null!=despatchAdvice && null!=despatchAdvice.getDespatchLine() && !despatchAdvice.getDespatchLine().isEmpty()){
			DespatchLineType despatchLineType=despatchAdvice.getDespatchLine().get(0);
			if(null!=despatchLineType.getShipment() && null!=despatchLineType.getShipment().getShippingDocs()){
				 List<DocumentType> documentTypeList= despatchLineType.getShipment().getShippingDocs().getDocument();
				 if(!documentTypeList.isEmpty() && null!=documentTypeList.get(0) ){
					 documentTypeList.get(0).setParams(paramsType);
			
				 }
			}
		}
		message.setPayload(despatchAdvice);
		return message;
	}
	
	

}
