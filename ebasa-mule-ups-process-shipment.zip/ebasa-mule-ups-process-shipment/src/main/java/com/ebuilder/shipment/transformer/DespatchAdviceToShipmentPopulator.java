/**
 * 
 */
package com.ebuilder.shipment.transformer;

import java.util.List;

import com.ebuilder.ebtransport.ubleb.despatchadvice.ContactType;
import com.ebuilder.ebtransport.ubleb.despatchadvice.CustomerPartyType;
import com.ebuilder.ebtransport.ubleb.despatchadvice.DespatchAdviceType;
import com.ebuilder.ebtransport.ubleb.despatchadvice.GoodsItemType;
import com.ebuilder.ebtransport.ubleb.despatchadvice.PartyType;
import com.ebuilder.shipment.dto.ValidationResultDTO;
import com.ebuilder.shipment.validation.ShipWSRequestValidationRule;
import com.ebuilder.shipment.validation.UPSWSRequestValidator;
import com.ebuilder.util.Constants;
import com.ebuilder.util.StringUtils;
import com.ups.ship.BillShipperType;
import com.ups.ship.LabelImageFormatType;
import com.ups.ship.LabelSpecificationType;
import com.ups.ship.PackageType;
import com.ups.ship.PackageWeightType;
import com.ups.ship.PackagingType;
import com.ups.ship.PaymentInfoType;
import com.ups.ship.RequestType;
import com.ups.ship.ReturnServiceType;
import com.ups.ship.ServiceType;
import com.ups.ship.ShipAddressType;
import com.ups.ship.ShipFromType;
import com.ups.ship.ShipPhoneType;
import com.ups.ship.ShipToAddressType;
import com.ups.ship.ShipToType;
import com.ups.ship.ShipUnitOfMeasurementType;
import com.ups.ship.ShipmentChargeType;
import com.ups.ship.ShipmentRequest;
import com.ups.ship.ShipmentType;
import com.ups.ship.ShipperType;

/**
 * @author upesh
 *
 */
public class DespatchAdviceToShipmentPopulator {
	
	private UPSWSRequestValidator requestValidator=null;
	private ShipWSRequestValidationRule requestValidationRule=null;
	
	public static final String NON_VALIDATE_ADDRESS = "nonvalidate";
	public static final String SHIPMENT_DESCRIPTION="Mobile phones";
	
	public DespatchAdviceToShipmentPopulator() {
		this.requestValidator = new UPSWSRequestValidator();
		this.requestValidationRule = new ShipWSRequestValidationRule();
		this.requestValidator.setRule(requestValidationRule);	
	}
	
	public ShipmentRequest processRequest(DespatchAdviceType despatchAdviceType,ShipmentRequest shipRequest ) throws Exception {
		//final CarrierResponseDTO responseDTO = new CarrierResponseDTO();
		final ValidationResultDTO resultDTO = this.requestValidator.validate(despatchAdviceType);
		if (StringUtils.isNotEmpty(resultDTO.getStatus()) && resultDTO.getStatus().equals(Constants.FAILURE_RESPONSE)) {
			/*responseDTO.setFail(true);
			if (resultDTO.getExceptionDTOs() != null) {
				responseDTO.setExceptionDTOList(resultDTO.getExceptionDTOs());
				responseDTO.setErrorHolder(ErrorHolder.VALIDATION_ERROR);
			}	*/	
			
			throw new Exception("Validation Falis -Change lator");//TODO
			
		} else if (StringUtils.isNotEmpty(resultDTO.getStatus()) && resultDTO.getStatus().equals(Constants.SUCCESS_RESPONSE)) {			
			/*final ShipService shipService = new ShipService();
			final ShipPortType shipPort = shipService.getShipPort();
			final Client client = ClientProxy.getClient(shipPort);
			client.getInInterceptors().add(new LoggingInInterceptor());
			client.getOutInterceptors().add(new LoggingOutInterceptor());   
			final BindingProvider bindingProvider = (BindingProvider) shipPort;
			bindingProvider.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, UPSUtil.getInstance().getUrl(Constants.UPS_SHIP_WS_ATTRIBUTE_NAME));*/
			//final ShipmentRequest shipRequest = new ShipmentRequest();
			final RequestType requestType = new RequestType();
			final List<String> requestOption = requestType.getRequestOption();
			requestOption.add(NON_VALIDATE_ADDRESS);
			shipRequest.setRequest(requestType);
			final ShipmentType shipmentType = new ShipmentType();
			shipmentType.setDescription(SHIPMENT_DESCRIPTION);
			if (null!=despatchAdviceType.getBillingParty() && !despatchAdviceType.getBillingParty().isEmpty() ) {

				if ((despatchAdviceType.getBillingParty().equals(Constants.BillingParty.BILL_SHIPPER.getName())) 
						&& (despatchAdviceType.getOriginatorCustomerParty() != null)
						&& (despatchAdviceType.getOriginatorCustomerParty().getParty() != null)) {
					final CustomerPartyType shipmentPartyType = despatchAdviceType.getOriginatorCustomerParty();									
					setShipper(shipmentPartyType,despatchAdviceType, shipmentType);
				}

				if ((despatchAdviceType.getBillingParty().equals(Constants.BillingParty.BILL_RECEIVER.getName()))
						&& (despatchAdviceType.getDeliveryCustomerParty() != null) 
						&& (despatchAdviceType.getDeliveryCustomerParty().getParty() != null)) {					
					final CustomerPartyType shipmentPartyType = despatchAdviceType.getDeliveryCustomerParty();	
					setReturnService(shipmentType);
					setShipper(shipmentPartyType,despatchAdviceType, shipmentType);
				}
				if ((despatchAdviceType.getBillingParty().equals(Constants.BillingParty.BILL_THIRD_PARTY.getName()))
						&& (despatchAdviceType.getBillingThirdParty() != null) 
						&& (despatchAdviceType.getBillingThirdParty().getParty() != null)) {
					final CustomerPartyType shipmentPartyType = despatchAdviceType.getBillingThirdParty();	
					setReturnService(shipmentType);
					setShipper(shipmentPartyType,despatchAdviceType, shipmentType);
				}
			}

			if (despatchAdviceType.getDeliveryCustomerParty() != null) 
			{
				setShipTo(despatchAdviceType.getDeliveryCustomerParty(),shipmentType);
			}

			if ((null!=despatchAdviceType.getBillingParty() && !despatchAdviceType.getBillingParty().isEmpty()) 
					&&  ((despatchAdviceType.getBillingParty().equals(Constants.BillingParty.BILL_RECEIVER.getName()))
							|| (despatchAdviceType.getBillingParty().equals(Constants.BillingParty.BILL_THIRD_PARTY.getName())))
							&& (despatchAdviceType.getOriginatorCustomerParty() != null) 
							&& (despatchAdviceType.getOriginatorCustomerParty().getParty() != null) 
							&& (despatchAdviceType.getOriginatorCustomerParty().getParty().getPostalAddress() != null)) {
				final PartyType originPartyType = despatchAdviceType.getOriginatorCustomerParty().getParty();
				setShipFrom(originPartyType,shipmentType);
			}

			setPaymentInformation( despatchAdviceType,shipmentType);


			if (despatchAdviceType.getDespatchLine() != null 
					&& !despatchAdviceType.getDespatchLine().isEmpty()
					&& despatchAdviceType.getDespatchLine().get(0).getShipment() != null 
					&& StringUtils.isNotEmpty(despatchAdviceType.getDespatchLine().get(0).getShipment().getShippingPriorityLevelCode())) {
				final ServiceType service = new ServiceType();
				service.setCode(despatchAdviceType.getDespatchLine().get(0).getShipment().getShippingPriorityLevelCode());
				shipmentType.setService(service);
			}



			if (despatchAdviceType.getDespatchLine() != null 
					&& !despatchAdviceType.getDespatchLine().isEmpty()
					&& despatchAdviceType.getDespatchLine().get(0).getShipment() != null 
					&& despatchAdviceType.getDespatchLine().get(0).getShipment().getGoodsItem() != null) {
				final List<GoodsItemType> goodsItemTypes = despatchAdviceType.getDespatchLine().get(0).getShipment().getGoodsItem();
				setPackages(goodsItemTypes, shipmentType);
			}

			setLabel(shipRequest);

			shipRequest.setShipment(shipmentType);	
		/*	if (despatchAdviceType.getDespatchSupplierParty() != null) {
				final UPSSecurity upsSecurity = new UPSSecurity();
				setUPSSecurity(despatchAdviceType.getDespatchSupplierParty(), upsSecurity);
				try {
					final ShipmentResponse shipResponse = shipPort.processShipment(shipRequest, upsSecurity);					
					if(shipResponse!=null && shipResponse.getResponse()!=null
							&& shipResponse.getResponse().getResponseStatus()!=null
							&& StringUtils.isNotEmpty(shipResponse.getResponse().getResponseStatus().getDescription()) 
							&& shipResponse.getResponse().getResponseStatus().getDescription().equals(Constants.UPS_SUCCESS_RESPONSE)){
						responseDTO.setFail(false);
						if(shipResponse.getShipmentResults()!=null && StringUtils.isNotEmpty(shipResponse.getShipmentResults().getShipmentIdentificationNumber())){
							responseDTO.setConsignmentNo(shipResponse.getShipmentResults().getShipmentIdentificationNumber());                           
						}
						if(shipResponse.getShipmentResults()!=null
								&& shipResponse.getShipmentResults().getPackageResults()!=null 
								&& !shipResponse.getShipmentResults().getPackageResults().isEmpty() 
								&& shipResponse.getShipmentResults().getPackageResults().get(0)!=null 
								&& shipResponse.getShipmentResults().getPackageResults().get(0).getShippingLabel()!=null 
								&& shipResponse.getShipmentResults().getPackageResults().get(0).getShippingLabel().getGraphicImage()!=null){

							final byte[] encodedAwb=shipResponse.getShipmentResults().getPackageResults().get(0).getShippingLabel().getGraphicImage().getBytes();
							if(encodedAwb!=null && encodedAwb.length>0){								
								final byte[] decodedAwb=Base64.decodeBase64(encodedAwb);
								if(decodedAwb!=null && decodedAwb.length>0){
									final ByteArrayOutputStream outputStream=new ByteArrayOutputStream();
									setPDFOutputStream(decodedAwb,outputStream);									
									final List<DocumentDTO> documentDTOs=new ArrayList<DocumentDTO>();
									final DocumentDTO documentDTO=new DocumentDTO();
									documentDTO.setLabel(Constants.AWB_LABEL);											
									documentDTO.setContent(new String((Base64.encodeBase64(outputStream.toByteArray()))));
									documentDTO.setContentType(Constants.DOC_TYPES.PDF.getKey());
									documentDTOs.add(documentDTO);
									responseDTO.setDocumentList(documentDTOs);
								}	
							}
						}
					}
					else{
						responseDTO.setFail(true);
					}
				}
				catch(ShipmentErrorMessage e){
					responseDTO.setFail(true);
					if(e.getFaultInfo()!=null 
							&& e.getFaultInfo().getErrorDetail()!=null 
							&& !e.getFaultInfo().getErrorDetail().isEmpty()
							&& e.getFaultInfo().getErrorDetail().get(0).getPrimaryErrorCode()!=null){
						final List<ExceptionDTO> exceptionDTOs=new ArrayList<ExceptionDTO>();
						final ExceptionDTO exceptionDTO=new ExceptionDTO();
						exceptionDTO.setErrorCode(e.getFaultInfo().getErrorDetail().get(0).getPrimaryErrorCode().getCode());
						exceptionDTO.setErrorDescription(e.getFaultInfo().getErrorDetail().get(0).getPrimaryErrorCode().getDescription());
						exceptionDTOs.add(exceptionDTO);						
						responseDTO.setExceptionDTOList(exceptionDTOs);
						LOG.error(e.toString());
					}					
				}
			}*/
		}	
		return null;
	}
	
	
	private void setReturnService(final ShipmentType shipmentType){
		ReturnServiceType returnServiceType=new ReturnServiceType();
		returnServiceType.setCode(Constants.UPS_PRINT_RETURN_LABEL);
		returnServiceType.setDescription(Constants.SHIPMENT_DESCRIPTION);			
		shipmentType.setReturnService(returnServiceType);
	}

	private void setShipper(final CustomerPartyType shipmentPartyType, final DespatchAdviceType despatchAdvice,
	        final ShipmentType shipmentType) {

	    if (shipmentPartyType != null && shipmentPartyType.getParty() != null) {
			final ShipperType shipper = new ShipperType();
			final PartyType partyType = shipmentPartyType.getParty();
			if (shipmentPartyType.getParty().getPostalAddress() != null) {				
				final com.ebuilder.ebtransport.ubleb.despatchadvice.AddressType addressType = shipmentPartyType.getParty().getPostalAddress();
                String personName = partyType.getPerson();

                shipper.setName(partyType.getPartyName());

              if (StringUtils.isNotEmpty(personName) /*&& CarrierConnectorHelper.getInstance().isConsumer(partyType.getPartyID())*/) { //TODO  check
                    shipper.setName(personName);
                }

//				shipper.setName(partyType.getPartyName());

				if (shipmentPartyType.getDeliveryContact() != null
				        && StringUtils.isNotEmpty(shipmentPartyType.getDeliveryContact().getName())) {
					shipper.setAttentionName(shipmentPartyType.getDeliveryContact().getName());
				}

				if (despatchAdvice.getDespatchSupplierParty() != null 
						&& StringUtils.isNotEmpty(despatchAdvice.getDespatchSupplierParty().getCustomerAssignedAccountID())) {
					shipper.setShipperNumber(despatchAdvice.getDespatchSupplierParty().getCustomerAssignedAccountID());
				}

				final ShipAddressType shipperAddress = new ShipAddressType();

				final List<String> addrLineList = shipperAddress.getAddressLine();
				addrLineList.add(addressType.getStreetName());

				shipperAddress.setCity(addressType.getCityName());
				if(StringUtils.isNotEmpty(addressType.getPostalZone())){
					shipperAddress.setPostalCode(addressType.getPostalZone());
				}
				if(StringUtils.isNotEmpty(addressType.getRegion())){
					shipperAddress.setStateProvinceCode(addressType.getRegion());
				}
				if (addressType.getCountry() != null && StringUtils.isNotEmpty(addressType.getCountry().getIdentificationCode())) {
					shipperAddress.setCountryCode(addressType.getCountry().getIdentificationCode());
				}
				shipper.setAddress(shipperAddress);
			}
			String contactNo = getContactNo(partyType);
			if(StringUtils.isNotEmpty(contactNo)){
				final ShipPhoneType shipperPhone = new ShipPhoneType();
				shipperPhone.setNumber(contactNo);
				shipper.setPhone(shipperPhone);	
			}
			shipmentType.setShipper(shipper);			
		}
	}

	private void setShipTo(final CustomerPartyType deliveryPartyType, final ShipmentType shipmentType) {		
		if (deliveryPartyType != null && deliveryPartyType.getParty() != null) {
			final ShipToType shipTo = new ShipToType();

			if (deliveryPartyType.getParty().getPostalAddress() != null) {
				final com.ebuilder.ebtransport.ubleb.despatchadvice.AddressType delAddressType = deliveryPartyType.getParty().getPostalAddress();
				shipTo.setName(deliveryPartyType.getParty().getPartyName());

				if (deliveryPartyType.getDeliveryContact() != null && StringUtils.isNotEmpty(deliveryPartyType.getDeliveryContact().getName())) {
					shipTo.setAttentionName(deliveryPartyType.getDeliveryContact().getName());
				}

				String personName = deliveryPartyType.getParty().getPerson();

				if (StringUtils.isNotEmpty(personName)
				       /* && CarrierConnectorHelper.getInstance().isConsumer(deliveryPartyType.getParty().getPartyID())*/) {  //TODO check

				    shipTo.setName(personName);
				    shipTo.setAttentionName(personName);
				}

				final ShipToAddressType shipToAddress = new ShipToAddressType();           

				final List<String> addrLineList = shipToAddress.getAddressLine();
				addrLineList.add(delAddressType.getStreetName());

				shipToAddress.setCity(delAddressType.getCityName());

				if(StringUtils.isNotEmpty(delAddressType.getPostalZone())){
					shipToAddress.setPostalCode(delAddressType.getPostalZone());
				}
				if(StringUtils.isNotEmpty(delAddressType.getRegion())){
					shipToAddress.setStateProvinceCode(delAddressType.getRegion());
				}
				if (delAddressType.getCountry() != null && delAddressType.getCountry().getIdentificationCode() != null) {
					shipToAddress.setCountryCode(delAddressType.getCountry().getIdentificationCode());
				}
				shipTo.setAddress(shipToAddress);
			}
			String contactNo = getContactNo(deliveryPartyType.getParty());
			if(StringUtils.isNotEmpty(contactNo)){
				ShipPhoneType shipToPhone = new ShipPhoneType();
				shipToPhone.setNumber(contactNo);
				shipTo.setPhone(shipToPhone);	
			}
			shipmentType.setShipTo(shipTo);
		}
	}

	private void setShipFrom(final PartyType originPartyType,final ShipmentType shipmentType){
		if(originPartyType!=null 
				&& originPartyType.getPostalAddress()!=null){
			final com.ebuilder.ebtransport.ubleb.despatchadvice.AddressType originAddressType = originPartyType.getPostalAddress();		
			final ShipFromType shipFrom = new ShipFromType();
			shipFrom.setName(originPartyType.getPartyName());
			if(originPartyType.getContact()!=null && StringUtils.isNotEmpty(originPartyType.getContact().getName())){
				shipFrom.setAttentionName(originPartyType.getContact().getName());
			}
			final ShipAddressType shipFromAddress = new ShipAddressType();

			if(StringUtils.isNotEmpty(originAddressType.getStreetName())){
				final List<String> addrLineList = shipFromAddress.getAddressLine();
				addrLineList.add(originAddressType.getStreetName());
			}

			if(StringUtils.isNotEmpty(originAddressType.getCityName())){
				shipFromAddress.setCity(originAddressType.getCityName());
			}

			if(StringUtils.isNotEmpty(originAddressType.getPostalZone())){
				shipFromAddress.setPostalCode(originAddressType.getPostalZone());
			}
			if(StringUtils.isNotEmpty(originAddressType.getRegion())){
				shipFromAddress.setStateProvinceCode(originAddressType.getRegion());
			}
			if (originAddressType.getCountry() != null){
				shipFromAddress.setCountryCode(originAddressType.getCountry().getIdentificationCode());
			}
			shipFrom.setAddress(shipFromAddress);
			shipmentType.setShipFrom(shipFrom);
		}

	}

	private void setPaymentInformation(final DespatchAdviceType despatchAdvice,final ShipmentType shipmentType ){
		if(despatchAdvice.getDespatchSupplierParty()!=null 
				&& StringUtils.isNotEmpty(despatchAdvice.getDespatchSupplierParty().getCustomerAssignedAccountID())){
			final PaymentInfoType payInfo = new PaymentInfoType();
			final ShipmentChargeType shipmentCharge = new ShipmentChargeType();
			shipmentCharge.setType(Constants.TRANSPORTATION);
			final BillShipperType billShipper = new BillShipperType();
			billShipper.setAccountNumber(despatchAdvice.getDespatchSupplierParty().getCustomerAssignedAccountID());
			shipmentCharge.setBillShipper(billShipper);		
			final List<ShipmentChargeType> shipmentCharges = payInfo.getShipmentCharge();
			shipmentCharges.add(shipmentCharge);
			shipmentType.setPaymentInformation(payInfo);
		}
	}
	
	
	private void setPackages(final List<GoodsItemType> goodsItemTypes,final ShipmentType shipmentType ){
		final List<PackageType> packageList = shipmentType.getPackage();
		for (GoodsItemType goodsItemType : goodsItemTypes) {
			final PackageType packageType = new PackageType();
			packageType.setDescription(Constants.SHIPMENT_DESCRIPTION);
			final PackagingType packagingType = new PackagingType();
			packagingType.setCode(Constants.CUSTOMER_SUPPLIED_PACKAGE);
			packageType.setPackaging(packagingType);
			final PackageWeightType weight = new PackageWeightType();
			weight.setWeight(goodsItemType.getGrossWeightMeasure());
			final ShipUnitOfMeasurementType shpUnitOfMeas = new ShipUnitOfMeasurementType();
			shpUnitOfMeas.setCode(Constants.UNIT_OF_MEASURE_KILOGRAM);
			weight.setUnitOfMeasurement(shpUnitOfMeas);
			packageType.setPackageWeight(weight);
			packageList.add(packageType);
		}
	}

	private void setLabel(final ShipmentRequest shipRequest){

		final LabelSpecificationType labelSpecType = new LabelSpecificationType();
		final LabelImageFormatType labelImageFormat = new LabelImageFormatType();
		labelImageFormat.setCode(Constants.UPS_LABEL_IMAGE_FORMAT);
		labelSpecType.setLabelImageFormat(labelImageFormat);
		shipRequest.setLabelSpecification(labelSpecType);

	}
	
	/**
	 * if party type is consumer then the highest priority given to other communication field
	 * because other communication field holds the mobile no of the consumer
	 * @param partyType
	 * @return String
	 */
	private String getContactNo(final PartyType partyType){
		String contactNo = null;
		if(partyType.getContact() != null){			
			final ContactType contactType = partyType.getContact();
			if(StringUtils.isNotEmpty(contactType.getTelephone())){
				contactNo = contactType.getTelephone();
			}
			//TODO check
			if(/*CarrierConnectorHelper.getInstance().isConsumer(partyType.getPartyID())
						&&*/ StringUtils.isNotEmpty(contactType.getOtherCommunication())){
				contactNo = contactType.getOtherCommunication().get(0);
			}
		}
		return contactNo;
	}
	

}
