package com.ebuilder.shipment.validation;

import com.ebuilder.ebtransport.ubleb.despatchadvice.CustomerPartyType;
import com.ebuilder.ebtransport.ubleb.despatchadvice.DespatchAdviceType;
import com.ebuilder.ebtransport.ubleb.despatchadvice.PartyType;
import com.ebuilder.shipment.validation.dto.CarrierResponseDTO;
import com.ebuilder.shipment.validation.dto.ExceptionDTO;
import com.ebuilder.util.StringUtils;
import com.ups.ship.ShipmentRequest;

public class PartyTypeValidator extends AbstractValidator {
	
	private CustomerPartyType deliveryPartyType;
	private String context;
	
		
	public CarrierResponseDTO validate(DespatchAdviceType despatchAdvice,ShipmentRequest shipRequest,CarrierResponseDTO response){
		
		if (deliveryPartyType.getParty() != null) {

			final PartyType partyType = deliveryPartyType.getParty();
			if (StringUtils.isEmpty(partyType.getPartyName())) {
				getExceptionHolder().add(new ExceptionDTO(context,"Name Missing"));
			}
			else if(partyType.getPartyName().length()>35){
				String partyName=partyType.getPartyName().substring(0,35);
				partyType.setPartyName(partyName);
			}
			if (partyType.getPostalAddress() != null) {
			//	validateAddress(context,partyType.getPostalAddress(),getExceptionHolder());
				//TODO
			}

		}
		return super.validate(despatchAdvice,shipRequest,response);
	}


	public void setDeliveryPartyType(CustomerPartyType deliveryPartyType) {
		this.deliveryPartyType = deliveryPartyType;
	}


	public void setContext(String context) {
		this.context = context;
	}


	@Override
	public void populate(DespatchAdviceType despatchAdviceType,
			ShipmentRequest shipRequest) {
		// TODO Auto-generated method stub
		
	}

}
