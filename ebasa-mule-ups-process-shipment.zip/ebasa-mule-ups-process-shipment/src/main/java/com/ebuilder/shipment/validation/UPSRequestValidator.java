/**
 * 
 */
package com.ebuilder.shipment.validation;

import java.util.List;

import org.apache.log4j.Logger;

import com.ebuilder.ebtransport.ubleb.despatchadvice.DespatchAdviceType;
import com.ebuilder.shipment.validation.dto.CarrierResponseDTO;
import com.ebuilder.util.Constants;
import com.ups.ship.LabelImageFormatType;
import com.ups.ship.LabelSpecificationType;
import com.ups.ship.RequestType;
import com.ups.ship.ShipmentRequest;
import com.ups.ship.ShipmentType;

/**
 * @author upesh
 *
 */
public final class UPSRequestValidator {
	private static final Logger LOG = Logger.getLogger(UPSRequestValidator.class);

	private ShipperValidator shipperValidator = new ShipperValidator();
	private ShipToPartyTypeValidator shipToPartyTypeValidator = new ShipToPartyTypeValidator();
	private ShipFromPartyTypeValidator shipFromPartyTypeValidator = new ShipFromPartyTypeValidator();
	private PaymentInfoValidator paymentInfoValidator = new PaymentInfoValidator();
	private CarrierServiceValidator carrierServiceValidator = new CarrierServiceValidator();
	private PackageValidator packageValidator = new PackageValidator();

	public UPSRequestValidator() {

	}

	public CarrierResponseDTO validate(DespatchAdviceType despatchAdviceType, ShipmentRequest shipRequest) {
		LOG.info("Request Validation Chain Started");
		CarrierResponseDTO response = new CarrierResponseDTO();
		shipperValidator.next(shipToPartyTypeValidator);
		shipToPartyTypeValidator.next(shipFromPartyTypeValidator);
		shipFromPartyTypeValidator.next(carrierServiceValidator);
		carrierServiceValidator.next(paymentInfoValidator);
		paymentInfoValidator.next(packageValidator);

		final RequestType requestType = new RequestType();
		final List<String> requestOption = requestType.getRequestOption();
		requestOption.add(Constants.NON_VALIDATE_ADDRESS);
		shipRequest.setRequest(requestType);
		final ShipmentType shipmentType = new ShipmentType();
		shipRequest.setShipment(shipmentType);
		shipmentType.setDescription(Constants.SHIPMENT_DESCRIPTION);
		// setLabelInfo
		setLabel(shipRequest);

		return shipperValidator.validate(despatchAdviceType, shipRequest, response);
	}

	private void setLabel(final ShipmentRequest shipRequest) {

		final LabelSpecificationType labelSpecType = new LabelSpecificationType();
		final LabelImageFormatType labelImageFormat = new LabelImageFormatType();
		labelImageFormat.setCode(Constants.UPS_LABEL_IMAGE_FORMAT);
		labelSpecType.setLabelImageFormat(labelImageFormat);
		shipRequest.setLabelSpecification(labelSpecType);

	}

}
