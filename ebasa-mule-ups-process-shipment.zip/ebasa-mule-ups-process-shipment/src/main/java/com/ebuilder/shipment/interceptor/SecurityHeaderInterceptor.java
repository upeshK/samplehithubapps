/**
 * 
 */
package com.ebuilder.shipment.interceptor;

import java.util.HashMap;

import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.cxf.binding.soap.SoapMessage;
import org.apache.cxf.binding.soap.interceptor.AbstractSoapInterceptor;
import org.apache.cxf.headers.Header;
import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.phase.Phase;
import org.dom4j.tree.DefaultText;
import org.mule.api.MuleEvent;
import org.mule.api.transport.PropertyScope;
import org.mule.module.cxf.CxfConstants;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

/**
 * @author upesh
 *
 */
public class SecurityHeaderInterceptor extends AbstractSoapInterceptor {

	private static final String XMLNS = "http://www.ups.com/XMLSchema/XOLTWS/UPSS/v1.0";
	private String userName;
	private String password;
	private String licenceNor;

	public SecurityHeaderInterceptor(HashMap<String, String> map) {
		super(Phase.PRE_STREAM);
		// super(Phase.WRITE);
		// addAfter(LoggingOutInterceptor.class.getName());
		// addBefore(XmlPrologInterceptor.class.getName());
		// addBefore(StaxOutInterceptor.class.getName());
		this.userName = map.get("Username");
		this.password = map.get("Password");
		this.licenceNor = map.get("AccessLicenseNumber");
	}

	@Override
	public void handleMessage(SoapMessage message) throws Fault {

		MuleEvent event = (MuleEvent) message.getExchange().get(CxfConstants.MULE_EVENT);
		this.userName =event.getMessage().getProperty("userName", PropertyScope.OUTBOUND);
		//this.password = ((DefaultText) event.getMessage().getProperty("password", PropertyScope.SESSION)).getText();
		this.password = event.getMessage().getProperty("password", PropertyScope.OUTBOUND);
		this.licenceNor = event.getMessage().getProperty("accessKey", PropertyScope.OUTBOUND);
		Object obj =event.getMessage().getProperty("despatchReq", PropertyScope.OUTBOUND);
		event.getMessage().setOutboundProperty("despatchReqOrig", obj);
		
		DocumentBuilder builder;
		message.put("org.apache.cxf.stax.force-start-document", Boolean.TRUE);

		try {
			builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
		} catch (ParserConfigurationException e) {
			throw new Fault(e);
		}
		Document document = builder.newDocument();
		Element usernameToken = document.createElement("UsernameToken");
		usernameToken.setAttribute("xmlns", XMLNS);

		Element usernameEle = document.createElement("Username");
		usernameEle.setAttribute("xmlns", XMLNS);
		usernameEle.appendChild(document.createTextNode(this.userName));

		Element passwordEle = document.createElement("Password");
		passwordEle.setAttribute("xmlns", XMLNS);
		passwordEle.appendChild(document.createTextNode(this.password));

		usernameToken.appendChild(usernameEle);
		usernameToken.appendChild(passwordEle);

		Element serviceAccToken = document.createElement("ServiceAccessToken");
		serviceAccToken.setAttribute("xmlns", XMLNS);

		Element accLicencenorEle = document.createElement("AccessLicenseNumber");
		accLicencenorEle.setAttribute("xmlns", XMLNS);
		accLicencenorEle.appendChild(document.createTextNode(this.licenceNor));

		serviceAccToken.appendChild(accLicencenorEle);

		Element upsSecurity = document.createElement("UPSSecurity");
		upsSecurity.setAttribute("xmlns", XMLNS);
		upsSecurity.appendChild(usernameToken);
		upsSecurity.appendChild(serviceAccToken);

		message.put("disable.outputstream.optimization", Boolean.TRUE);
		message.setContent(Node.class, document);

		QName qnameSecurity = new QName("UPSSecurity");
		Header securityHeader = new Header(qnameSecurity, upsSecurity);
		message.getHeaders().add(securityHeader);
	}
}
