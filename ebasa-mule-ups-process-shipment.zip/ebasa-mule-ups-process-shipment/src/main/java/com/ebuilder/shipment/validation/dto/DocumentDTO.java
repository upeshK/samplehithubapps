package com.ebuilder.shipment.validation.dto;

import java.io.Serializable;


public class DocumentDTO implements Serializable{

    /**
     * 
     */
    private static final long serialVersionUID = 6386287239476052730L;
    private String label;
    private Long archiveDid;
    private String content;
    private String contentType;

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public Long getArchiveDid() {
        return archiveDid;
    }

    public void setArchiveDid(Long archiveDid) {
        this.archiveDid = archiveDid;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }
  
}
