/**
 * 
 */
package com.ebuilder.shipment.interceptor;

import org.apache.cxf.binding.soap.SoapMessage;
import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.phase.AbstractPhaseInterceptor;
import org.apache.cxf.phase.Phase;
import org.apache.log4j.Logger;
import org.mule.api.ExceptionPayload;
import org.mule.api.MuleEvent;
import org.mule.api.MuleMessage;
import org.mule.message.DefaultExceptionPayload;
import org.mule.module.cxf.CxfConstants;

/**
 * @author upesh
 *
 */
public class CustomSoapFaultInterceptor extends AbstractPhaseInterceptor<SoapMessage> {

	private static final Logger logger = Logger.getLogger(CustomSoapFaultInterceptor.class);

	public CustomSoapFaultInterceptor() {
		super(Phase.POST_INVOKE);
	}

	@Override
	public void handleMessage(SoapMessage soapMessage) throws Fault {
		logger.info("Invoke handle Message");
		super.handleFault(soapMessage);
		Exception exception = soapMessage.getContent(Exception.class);
		// ShipmentErrorMessage msg=(ShipmentErrorMessage)exception;
		MuleEvent event = (MuleEvent) soapMessage.getExchange().get(CxfConstants.MULE_EVENT);
		MuleMessage muleMessage = event.getMessage();
		ExceptionPayload exceptionPayload = new DefaultExceptionPayload(exception);
		muleMessage.setExceptionPayload(exceptionPayload);
	}

}
