/**
 * 
 */
package com.ebuilder.shipment.exception;

import org.mule.api.transformer.TransformerException;
import org.mule.config.i18n.Message;
import org.mule.transformer.AbstractTransformer;

/**
 * @author upesh
 *
 */
public class ShipmentFaultException extends TransformerException {
	
	private static final long serialVersionUID = 4269907777820473427L;
	
	public ShipmentFaultException(Message message, Throwable cause) {
		super(message, cause);
	}
	
	public ShipmentFaultException(Message message, AbstractTransformer transformer) {
		super(message, transformer);
	}
}
