/**
 * 
 */
package com.ebuilder.shipment.validation;

import org.apache.log4j.Logger;

import com.ebuilder.ebtransport.ubleb.despatchadvice.DespatchAdviceType;
import com.ebuilder.shipment.validation.dto.CarrierResponseDTO;
import com.ebuilder.shipment.validation.dto.ExceptionDTO;
import com.ebuilder.util.StringUtils;
import com.ups.ship.ServiceType;
import com.ups.ship.ShipmentRequest;

/**
 * @author upesh
 *
 */
public class CarrierServiceValidator extends AbstractValidator {
	private static final Logger LOG = Logger.getLogger(CarrierServiceValidator.class);

	public CarrierResponseDTO validate(DespatchAdviceType despatchAdvice, ShipmentRequest shipRequest, CarrierResponseDTO response) {
		LOG.info("Carrier Service Validation Started");
		if (despatchAdvice.getDespatchLine() != null && !despatchAdvice.getDespatchLine().isEmpty()
				&& despatchAdvice.getDespatchLine().get(0).getShipment() != null
				&& StringUtils.isEmpty(despatchAdvice.getDespatchLine().get(0).getShipment().getShippingPriorityLevelCode())) {
			getExceptionHolder().add(new ExceptionDTO("Carrier Service Missing"));
		}
		return super.validate(despatchAdvice, shipRequest, response);
	}

	@Override
	public void populate(DespatchAdviceType despatchAdviceType, ShipmentRequest shipRequest) {
		if (despatchAdviceType.getDespatchLine() != null && !despatchAdviceType.getDespatchLine().isEmpty()
				&& despatchAdviceType.getDespatchLine().get(0).getShipment() != null
				&& StringUtils.isNotEmpty(despatchAdviceType.getDespatchLine().get(0).getShipment().getShippingPriorityLevelCode())) {
			final ServiceType service = new ServiceType();
			service.setCode(despatchAdviceType.getDespatchLine().get(0).getShipment().getShippingPriorityLevelCode());
			shipRequest.getShipment().setService(service);
		}
	}

}
