/**
 * 
 */
package com.ebuilder.shipment.validation;

import java.util.List;

import org.apache.log4j.Logger;

import com.ebuilder.ebtransport.ubleb.despatchadvice.DespatchAdviceType;
import com.ebuilder.ebtransport.ubleb.despatchadvice.GoodsItemType;
import com.ebuilder.shipment.validation.dto.CarrierResponseDTO;
import com.ebuilder.shipment.validation.dto.ExceptionDTO;
import com.ebuilder.util.Constants;
import com.ebuilder.util.StringUtils;
import com.ups.ship.PackageType;
import com.ups.ship.PackageWeightType;
import com.ups.ship.PackagingType;
import com.ups.ship.ShipUnitOfMeasurementType;
import com.ups.ship.ShipmentRequest;
import com.ups.ship.ShipmentType;

/**
 * @author upesh
 *
 */
public class PackageValidator extends AbstractValidator {
	private static final Logger LOG = Logger.getLogger(PackageValidator.class);

	public CarrierResponseDTO validate(DespatchAdviceType despatchAdvice, ShipmentRequest shipRequest, CarrierResponseDTO response) {
		LOG.info("Package Validation Started");
		if (despatchAdvice.getDespatchLine() != null && !despatchAdvice.getDespatchLine().isEmpty()
				&& despatchAdvice.getDespatchLine().get(0).getShipment() != null
				&& despatchAdvice.getDespatchLine().get(0).getShipment().getGoodsItem() != null) {
			final List<GoodsItemType> goodsItemTypes = despatchAdvice.getDespatchLine().get(0).getShipment().getGoodsItem();
			for (GoodsItemType goodsItemType : goodsItemTypes) {
				if (StringUtils.isEmpty(goodsItemType.getGrossWeightMeasure())) {
					getExceptionHolder().add(new ExceptionDTO("Package Weight Missing"));
				} else if (StringUtils.isNumber(goodsItemType.getGrossWeightMeasure())) {
					try {
						if ((Double.parseDouble(goodsItemType.getGrossWeightMeasure())) < (Constants.UPS_DEFAULT_WAIGHT)) {
							goodsItemType.setGrossWeightMeasure(Constants.STR_UPS_DEFAULT_WAIGHT);
						}
					} catch (NumberFormatException e) {
						LOG.error(
								"Package Validation Failed Icorrect format for GrossWeight Measure :: "
										+ goodsItemType.getGrossWeightMeasure(), e);
					}
				}
			}

		}
		return super.validate(despatchAdvice, shipRequest, response);
	}

	@Override
	public void populate(DespatchAdviceType despatchAdviceType, ShipmentRequest shipRequest) {
		if (despatchAdviceType.getDespatchLine() != null && !despatchAdviceType.getDespatchLine().isEmpty()
				&& despatchAdviceType.getDespatchLine().get(0).getShipment() != null
				&& despatchAdviceType.getDespatchLine().get(0).getShipment().getGoodsItem() != null) {
			final List<GoodsItemType> goodsItemTypes = despatchAdviceType.getDespatchLine().get(0).getShipment().getGoodsItem();
			setPackages(goodsItemTypes, shipRequest.getShipment());
		}

	}

	private void setPackages(final List<GoodsItemType> goodsItemTypes, final ShipmentType shipmentType) {
		final List<PackageType> packageList = shipmentType.getPackage();
		for (GoodsItemType goodsItemType : goodsItemTypes) {
			final PackageType packageType = new PackageType();
			packageType.setDescription(Constants.SHIPMENT_DESCRIPTION);
			final PackagingType packagingType = new PackagingType();
			packagingType.setCode(Constants.CUSTOMER_SUPPLIED_PACKAGE);
			packageType.setPackaging(packagingType);
			final PackageWeightType weight = new PackageWeightType();
			weight.setWeight(goodsItemType.getGrossWeightMeasure());
			final ShipUnitOfMeasurementType shpUnitOfMeas = new ShipUnitOfMeasurementType();
			shpUnitOfMeas.setCode(Constants.UNIT_OF_MEASURE_KILOGRAM);
			weight.setUnitOfMeasurement(shpUnitOfMeas);
			packageType.setPackageWeight(weight);
			packageList.add(packageType);
		}
	}

}
