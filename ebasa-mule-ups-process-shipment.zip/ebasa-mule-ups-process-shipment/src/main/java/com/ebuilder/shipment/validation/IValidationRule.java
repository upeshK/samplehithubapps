/**
 * 
 */
package com.ebuilder.shipment.validation;

import com.ebuilder.ebtransport.ubleb.despatchadvice.DespatchAdviceType;
import com.ebuilder.shipment.dto.ValidationResultDTO;

/**
 * @author upesh
 *
 */
public interface IValidationRule {
	 ValidationResultDTO validate(DespatchAdviceType despatchAdvice);
}
