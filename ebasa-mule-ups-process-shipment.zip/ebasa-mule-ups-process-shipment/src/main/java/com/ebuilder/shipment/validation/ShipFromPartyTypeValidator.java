/**
 * 
 */
package com.ebuilder.shipment.validation;

import java.util.List;

import org.apache.log4j.Logger;

import com.ebuilder.ebtransport.ubleb.despatchadvice.AddressType;
import com.ebuilder.ebtransport.ubleb.despatchadvice.CustomerPartyType;
import com.ebuilder.ebtransport.ubleb.despatchadvice.DespatchAdviceType;
import com.ebuilder.ebtransport.ubleb.despatchadvice.PartyType;
import com.ebuilder.shipment.validation.dto.CarrierResponseDTO;
import com.ebuilder.shipment.validation.dto.ExceptionDTO;
import com.ebuilder.util.Constants;
import com.ebuilder.util.StringUtils;
import com.ups.ship.ShipAddressType;
import com.ups.ship.ShipFromType;
import com.ups.ship.ShipmentRequest;
import com.ups.ship.ShipmentType;

/**
 * @author upesh
 *
 */
public class ShipFromPartyTypeValidator extends AbstractValidator {

	private static final Logger LOG = Logger.getLogger(ShipFromPartyTypeValidator.class);

	public CarrierResponseDTO validate(DespatchAdviceType despatchAdvice, ShipmentRequest shipRequest, CarrierResponseDTO response) {
		LOG.info("Ship From Party Validation Started");
		if ((StringUtils.isNotEmpty(despatchAdvice.getBillingParty()))
				&& ((despatchAdvice.getBillingParty().equals(Constants.BillingParty.BILL_RECEIVER.getName())) || (despatchAdvice
						.getBillingParty().equals(Constants.BillingParty.BILL_THIRD_PARTY.getName())))) {
			validateParty(Constants.SHIP_FROM_CONTEXT, despatchAdvice.getOriginatorCustomerParty());
		}
		return super.validate(despatchAdvice, shipRequest, response);
	}

	@Override
	public void populate(DespatchAdviceType despatchAdviceType, ShipmentRequest shipRequest) {
		if ((StringUtils.isNotEmpty(despatchAdviceType.getBillingParty()))
				&& ((despatchAdviceType.getBillingParty().equals(Constants.BillingParty.BILL_RECEIVER.getName())) || (despatchAdviceType
						.getBillingParty().equals(Constants.BillingParty.BILL_THIRD_PARTY.getName())))
				&& (despatchAdviceType.getOriginatorCustomerParty() != null)
				&& (despatchAdviceType.getOriginatorCustomerParty().getParty() != null)
				&& (despatchAdviceType.getOriginatorCustomerParty().getParty().getPostalAddress() != null)) {
			final PartyType originPartyType = despatchAdviceType.getOriginatorCustomerParty().getParty();
			setShipFrom(originPartyType, shipRequest.getShipment());
		}

	}

	private void setShipFrom(final PartyType originPartyType, final ShipmentType shipmentType) {
		if (originPartyType != null && originPartyType.getPostalAddress() != null) {
			final com.ebuilder.ebtransport.ubleb.despatchadvice.AddressType originAddressType = originPartyType.getPostalAddress();
			final ShipFromType shipFrom = new ShipFromType();
			shipFrom.setName(originPartyType.getPartyName());
			if (originPartyType.getContact() != null && StringUtils.isNotEmpty(originPartyType.getContact().getName())) {
				shipFrom.setAttentionName(originPartyType.getContact().getName());
			}
			final ShipAddressType shipFromAddress = new ShipAddressType();

			final List<String> addrLineList = shipFromAddress.getAddressLine();
			if (StringUtils.isNotEmpty(originAddressType.getStreetName())) {
				addrLineList.add(originAddressType.getStreetName());
			}
			if(StringUtils.isNotEmpty(originAddressType.getAdditionalStreetName())){
				addrLineList.add(1,originAddressType.getAdditionalStreetName().length()>35?originAddressType.getAdditionalStreetName().substring(0, 35):originAddressType.getAdditionalStreetName());
			}
			
			if(originAddressType.getAddressLine()!=null && !originAddressType.getAddressLine().isEmpty()){
				String addressLine3=originAddressType.getAddressLine().get(0);
				addrLineList.add(addressLine3.length()>35?addressLine3.substring(0, 35):addressLine3);
			}
			
			if (StringUtils.isNotEmpty(originAddressType.getCityName())) {
				shipFromAddress.setCity(originAddressType.getCityName());
			}

			if (StringUtils.isNotEmpty(originAddressType.getPostalZone())) {
				shipFromAddress.setPostalCode(originAddressType.getPostalZone());
			}
			if (StringUtils.isNotEmpty(originAddressType.getRegion())) {
				shipFromAddress.setStateProvinceCode(originAddressType.getRegion());
			}
			if (originAddressType.getCountry() != null) {
				shipFromAddress.setCountryCode(originAddressType.getCountry().getIdentificationCode());
			}
			shipFrom.setAddress(shipFromAddress);
			shipmentType.setShipFrom(shipFrom);
		}

	}

	private void validateParty(final String context, final CustomerPartyType deliveryPartyType) {
		if (deliveryPartyType.getParty() != null) {

			final PartyType partyType = deliveryPartyType.getParty();
			if (StringUtils.isEmpty(partyType.getPartyName())) {
				getExceptionHolder().add(new ExceptionDTO(context, "Name Missing"));
			} else if (partyType.getPartyName().length() > 35) {
				String partyName = partyType.getPartyName().substring(0, 35);
				partyType.setPartyName(partyName);
			}
			if (partyType.getPostalAddress() != null) {
				validateAddress(context, partyType.getPostalAddress());
			}

		}
	}

	private void validateAddress(final String context, final AddressType addressType) {

		if (addressType != null) {

			if (StringUtils.isEmpty(addressType.getStreetName())) {
				getExceptionHolder().add(new ExceptionDTO(context, "Address Missing"));
			} else if (addressType.getStreetName().length() > 35) {
				String addressLine = addressType.getStreetName().substring(0, 35);
				addressType.setStreetName(addressLine);
			}
			if (StringUtils.isEmpty(addressType.getCityName())) {
				getExceptionHolder().add(new ExceptionDTO(context, "City Missing"));
			} else if (addressType.getCityName().length() > 30) {
				String city = addressType.getCityName().substring(0, 30);
				addressType.setCityName(city);
			}

			if (addressType.getCountry() != null
					&& addressType.getCountry().getIdentificationCode() != null
					&& ((addressType.getCountry().getIdentificationCode().equals("US"))
							|| (addressType.getCountry().getIdentificationCode().equals("CA")) || (addressType.getCountry()
							.getIdentificationCode().equals("PR"))) && (StringUtils.isEmpty(addressType.getPostalZone()))) {
				getExceptionHolder().add(new ExceptionDTO(context, "Postal Code Missing For CA/US/PR"));

			}

			if (StringUtils.isNotEmpty(addressType.getPostalZone()) && addressType.getPostalZone().length() > 9) {
				String postalZone = addressType.getPostalZone().substring(0, 9);
				addressType.setPostalZone(postalZone);
			}

			if (addressType.getCountry() != null
					&& addressType.getCountry().getIdentificationCode() != null
					&& ((addressType.getCountry().getIdentificationCode().equals("US")) || (addressType.getCountry()
							.getIdentificationCode().equals("CA"))) && (StringUtils.isEmpty(addressType.getRegion()))) {
				getExceptionHolder().add(new ExceptionDTO(context, "State/Province Missing For US/CA"));
			}

			if (addressType.getCountry() != null && StringUtils.isEmpty(addressType.getCountry().getIdentificationCode())) {
				getExceptionHolder().add(new ExceptionDTO(context, "Country Code Missing"));
			}

		}
	}

}
