/**
 * 
 */
package com.ebuilder.shipment.transformer;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;
import org.mule.api.transport.PropertyScope;
import org.mule.config.i18n.MessageFactory;
import org.mule.transformer.AbstractMessageTransformer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ebuilder.ebtransport.ubleb.despatchadvice.DespatchAdviceType;
import com.ebuilder.ebtransport.ubleb.despatchadvice.DespatchLineType;
import com.ebuilder.ebtransport.ubleb.despatchadvice.DocumentType;
import com.ebuilder.ebtransport.ubleb.despatchadvice.ShipmentType;
import com.ebuilder.ebtransport.ubleb.despatchadvice.ShippingDocsType;
import com.ebuilder.shipment.exception.ShipmentFaultClientException;
import com.ebuilder.shipment.exception.ShipmentFaultRemoteException;
import com.ebuilder.util.Constants;
import com.ebuilder.util.StringUtils;
import com.ups.ship.PackageResultsType;
import com.ups.ship.ShipmentResponse;
import com.ups.ship.ShipmentResultsType;


/**
 * @author upesh
 *
 */
public class ShipmentResToDespatchAdviceOriginalRequestTransformer extends AbstractMessageTransformer {
	
	private static final String DESPATCH_REQ = "despatchReq";

	private static final String RESPONSE_COM_DHL = "com.ups.ship";

	private static final String UTF_8 = "UTF-8";


	private static final Logger LOGGER = LoggerFactory.getLogger(ShipmentResToDespatchAdviceOriginalRequestTransformer.class);
	
	private JAXBContext despatchAdviceResJaxbContext = null;
	private JAXBContext shipmentResJaxbContext = null;

	public ShipmentResToDespatchAdviceOriginalRequestTransformer() throws JAXBException {
		this.despatchAdviceResJaxbContext = JAXBContext.newInstance(DespatchAdviceType.class.getPackage().getName());
		this.shipmentResJaxbContext = JAXBContext.newInstance(RESPONSE_COM_DHL);
	}

	@Override
	public Object transformMessage(MuleMessage message, String outputEncoding)
			throws TransformerException {
		return this.pojoTransform(message, message.getPayload(), outputEncoding);
		
	}
	
	/**
	 * Simple POJO transformer method that can be tested with plain unit testing.
	 * 
	 * @param payload message payload
	 * @param outputEncoding output encoding
	 * @return
	 * @throws TransformerException if transformation error
	 */
	protected byte[] pojoTransform(MuleMessage message, Object payload, String outputEncoding) throws TransformerException {
		ShipmentResponse shipmentResponse = payloadAsShipmentResponse(payload);
		DespatchAdviceType despatchAdvice=(DespatchAdviceType)message.getProperty(DESPATCH_REQ, PropertyScope.SESSION);
			

		try {
			mapDespatchLine(shipmentResponse,despatchAdvice);
			
		} catch(Exception e) {
			e.printStackTrace();
			throw new ShipmentFaultClientException(MessageFactory.createStaticMessage("transformation failed: " + e.getMessage()), this);
		}

		ByteArrayOutputStream response = new ByteArrayOutputStream();
		try {
			Marshaller marshaller = despatchAdviceResJaxbContext.createMarshaller();
			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			marshaller.setProperty(Marshaller.JAXB_ENCODING, outputEncoding);
			marshaller.marshal(despatchAdvice, response);
		} catch (JAXBException e) {
			throw new ShipmentFaultRemoteException(MessageFactory.createStaticMessage("transformation failed: " + e.getMessage()), this);
		}
		return response.toByteArray();
	}
	
	/**
	 * Convert the payload into a Shipment Response
	 * @param payload
	 * @return
	 * @throws TransformerException
	 */
	private ShipmentResponse payloadAsShipmentResponse(Object payload) throws TransformerException {
		try {
			if(payload == null) {
				throw new TransformerException(MessageFactory.createStaticMessage("empty payload"), this);
			}
			else if(payload instanceof ShipmentResponse) {
				return (ShipmentResponse)payload;
			}
			else if(payload instanceof String) {
				return payloadAsShipmentResponse(new ByteArrayInputStream(((String)payload).getBytes(UTF_8)));
			}
			else if(payload instanceof byte[]) {
				return payloadAsShipmentResponse(new ByteArrayInputStream((byte[])payload));
			}
			else if(payload instanceof InputStream) {
				Unmarshaller unmarshaller = shipmentResJaxbContext.createUnmarshaller();
				Object unmarshalledObject = unmarshaller.unmarshal((InputStream)payload);
				if(unmarshalledObject == null) {
					return null;
				}
				if(!(unmarshalledObject instanceof ShipmentResponse)) {
					throw new Exception("invalid class " + unmarshalledObject.getClass().getName() + " from unmarshaller");
				}
				@SuppressWarnings("unchecked")
				//JAXBElement<ShipmentResponse> jaxbElement = (JAXBElement<ShipmentResponse>)unmarshalledObject;
				ShipmentResponse response=(ShipmentResponse)unmarshalledObject;
				return response;
			}
			else {
				throw new TransformerException(MessageFactory.createStaticMessage("unexpected payload: " + payload.getClass().getName()), this);
			}
		} catch(Exception e) {
			throw new TransformerException(MessageFactory.createStaticMessage(e.getMessage()), e);
		}
	}

	
		
	private void mapDespatchLine(ShipmentResponse shipResponse, DespatchAdviceType despatchAdvice) throws Exception{
			
		if(shipResponse!=null && shipResponse.getResponse()!=null
				&& shipResponse.getResponse().getResponseStatus()!=null
				&& StringUtils.isNotEmpty(shipResponse.getResponse().getResponseStatus().getDescription()) 
				&& shipResponse.getResponse().getResponseStatus().getDescription().equals(Constants.UPS_SUCCESS_RESPONSE)){
			
			if(null!=despatchAdvice.getDespatchLine() && !despatchAdvice.getDespatchLine().isEmpty()){
				DespatchLineType despatchLineType =despatchAdvice.getDespatchLine().get(0);
				ShipmentType shipmentType =despatchLineType.getShipment();
				ShippingDocsType shippingDocsType=new ShippingDocsType();
				shipmentType.setShippingDocs(shippingDocsType);
				DocumentType documentType=new DocumentType();
				
				
				ShipmentResultsType shipmentResultsType=shipResponse.getShipmentResults();
				
				if(shipmentResultsType!=null){
					
					//populate AWB number
					if(StringUtils.isNotEmpty(shipmentResultsType.getShipmentIdentificationNumber())){
						shipmentType.setID(shipmentResultsType.getShipmentIdentificationNumber());
						documentType.setName(Constants.AWB_LABEL);
						documentType.setNumber(shipmentResultsType.getShipmentIdentificationNumber());
						shippingDocsType.getDocument().add(documentType);
					}
					
					//populate Label
					List<PackageResultsType> pkgResultsTypeList=shipmentResultsType.getPackageResults();
					if(pkgResultsTypeList!=null	&& !pkgResultsTypeList.isEmpty() && pkgResultsTypeList.get(0)!=null 
							&& pkgResultsTypeList.get(0).getShippingLabel()!=null 
							&& pkgResultsTypeList.get(0).getShippingLabel().getGraphicImage()!=null){
						
						documentType.setContent(pkgResultsTypeList.get(0).getShippingLabel().getGraphicImage().getBytes());
						//TODO setContentType eg. PDF,GIF etc.
					}
					
				}
			}
		}
	}
	

}
