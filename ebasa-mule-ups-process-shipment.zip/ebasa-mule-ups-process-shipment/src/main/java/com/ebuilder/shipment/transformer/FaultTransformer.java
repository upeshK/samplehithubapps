/**
 * 
 */
package com.ebuilder.shipment.transformer;

import java.io.ByteArrayOutputStream;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import org.apache.log4j.Logger;
import org.mule.api.MuleEventContext;
import org.mule.api.MuleMessage;
import org.mule.api.transport.PropertyScope;

import com.ebuilder.commons.muleapi.exceptionformatter.ExceptionFormatEntry;
import com.ebuilder.commons.muleapi.exceptionformatter.ExceptionFormatter;
import com.ebuilder.commons.muleapi.exceptions.ApplicationException;
import com.ebuilder.ebtransport.ubleb.despatchadvice.DespatchAdviceType;
import com.ebuilder.ebtransport.ubleb.despatchadvice.DespatchLineType;
import com.ebuilder.ebtransport.ubleb.despatchadvice.DocumentType;
import com.ebuilder.ebtransport.ubleb.despatchadvice.ParamType;
import com.ebuilder.ebtransport.ubleb.despatchadvice.ParamsType;
import com.ebuilder.ebtransport.ubleb.despatchadvice.ShippingDocsType;
import com.ups.ship.ErrorDetailType;
import com.ups.ship.ShipmentErrorMessage;

/**
 * @author upesh
 *
 */

public class FaultTransformer implements ExceptionFormatter {

	private static final Logger logger = Logger.getLogger(FaultTransformer.class);
	private static final String DESPATCH_REQ = "despatchReq";
	private static final String UTF_8 = "UTF-8";
	private JAXBContext despatchAdviceResJaxbContext = null;

	public FaultTransformer() throws JAXBException {
		this.despatchAdviceResJaxbContext = JAXBContext.newInstance(DespatchAdviceType.class.getPackage().getName());
	}

	@Override
	public ExceptionFormatEntry format(MuleEventContext eventContext, ApplicationException exception) {

		Throwable cause = exception.getCause();
		ParamsType paramsType = new ParamsType();
		ExceptionFormatEntry exceptionFormatEntry = new ExceptionFormatEntry();
		//Format Error Responses for SOAPFault 
		if (cause instanceof ShipmentErrorMessage) {
			ShipmentErrorMessage errorMessage = (ShipmentErrorMessage) cause;
			if (null != errorMessage.getFaultInfo()) {
				List<ErrorDetailType> errorDetailTypes = errorMessage.getFaultInfo().getErrorDetail();
				for (ErrorDetailType detailType : errorDetailTypes) {
					if (null != detailType.getPrimaryErrorCode()) {
						ParamType paramType = new ParamType();
						paramsType.getParam().add(paramType);
						paramType.setKey(detailType.getPrimaryErrorCode().getCode());
						paramType.setValue(detailType.getPrimaryErrorCode().getDescription());
					}
				}
			}
		} else {

			String msg = cause.getMessage();
			ParamType paramType = new ParamType();
			paramsType.getParam().add(paramType);
			paramType.setKey(String.valueOf(exception.getMessageCode()));
			paramType.setValue(msg);
		}

		MuleMessage message = eventContext.getMessage();
		DespatchAdviceType despatchAdvice = (DespatchAdviceType) message.getProperty(DESPATCH_REQ, PropertyScope.SESSION);

		if (null != despatchAdvice && null != despatchAdvice.getDespatchLine() && !despatchAdvice.getDespatchLine().isEmpty()) {
			DespatchLineType despatchLineType = despatchAdvice.getDespatchLine().get(0);
			if (null != despatchLineType.getShipment()) {
				if (null == despatchLineType.getShipment().getShippingDocs()) {
					ShippingDocsType shippingDocsType = new ShippingDocsType();
					despatchLineType.getShipment().setShippingDocs(shippingDocsType);
				}
				List<DocumentType> documentTypeList = despatchLineType.getShipment().getShippingDocs().getDocument();
				DocumentType docType = new DocumentType();
				documentTypeList.add(docType);
				docType.setParams(paramsType);
			}

		}

		ByteArrayOutputStream errResponseStream = new ByteArrayOutputStream();
		try {
			Marshaller marshaller = despatchAdviceResJaxbContext.createMarshaller();
			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			marshaller.setProperty(Marshaller.JAXB_ENCODING, UTF_8);
			marshaller.marshal(despatchAdvice, errResponseStream);
		} catch (JAXBException e) {
			logger.error("Marshalling Error",e);
		}

		exceptionFormatEntry.setData(errResponseStream.toByteArray());
		exceptionFormatEntry.setContentType("application/xml");

		return exceptionFormatEntry;

	}

}
