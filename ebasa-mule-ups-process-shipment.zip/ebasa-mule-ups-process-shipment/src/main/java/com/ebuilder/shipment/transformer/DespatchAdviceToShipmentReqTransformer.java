/**
 * 
 */
package com.ebuilder.shipment.transformer;

import java.io.ByteArrayInputStream;
import java.io.InputStream;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.apache.log4j.Logger;
import org.mule.DefaultMuleMessage;
import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;
import org.mule.api.transport.PropertyScope;
import org.mule.config.i18n.MessageFactory;
import org.mule.transformer.AbstractMessageTransformer;

import com.ebuilder.ebtransport.ubleb.despatchadvice.DespatchAdviceType;
import com.ebuilder.shipment.exception.ShipmentFaultClientException;
import com.ebuilder.shipment.validation.UPSRequestValidator;
import com.ebuilder.shipment.validation.dto.CarrierResponseDTO;
import com.ebuilder.shipment.validation.dto.ExceptionDTO;
import com.ebuilder.util.StringUtils;
import com.ups.ship.ShipmentRequest;

/**
 * @author upesh
 *
 */
public class DespatchAdviceToShipmentReqTransformer extends AbstractMessageTransformer {
	private static final String UTF_8 = "UTF-8";
	private static final Logger logger = Logger.getLogger(DespatchAdviceToShipmentReqTransformer.class);
	private JAXBContext despatchAdviceJaxbContext = null;

	public DespatchAdviceToShipmentReqTransformer() throws JAXBException {
		this.despatchAdviceJaxbContext = JAXBContext.newInstance(DespatchAdviceType.class.getPackage().getName());
	}

	@Override
	public Object transformMessage(MuleMessage message, String outputEncoding) throws TransformerException {
		outputEncoding = UTF_8;
		return this.pojoTransform(message, message.getPayload(), outputEncoding);
	}

	/**
	 * Simple POJO transformer method that can be tested with plain unit
	 * testing.
	 * 
	 * @param payload
	 *            message payload
	 * @param outputEncoding
	 *            output encoding
	 * @return
	 * @throws TransformerException
	 *             if transformation error
	 */
	protected Object pojoTransform(MuleMessage message, Object payload, String outputEncoding) throws TransformerException {
		logger.info("Transeform Despatch Advice Request");
		DespatchAdviceType despatchAdviceType = payloadAsDespatchAdvice(payload);
				
		// Set original payload (Original request from ASA) to session variable
		message.setProperty("despatchReq", despatchAdviceType, PropertyScope.SESSION);
		ShipmentRequest shipmentRequest = new ShipmentRequest();

		try {

			//validate access data
			validateUserAccessData(message, despatchAdviceType);
			// Validate DA Request
			UPSRequestValidator requestValidator = new UPSRequestValidator();

			CarrierResponseDTO responseDTO = requestValidator.validate(despatchAdviceType, shipmentRequest);

			if (null != responseDTO.getExceptionDTOList() && !responseDTO.getExceptionDTOList().isEmpty()) {

				StringBuilder builder = new StringBuilder();

				for (int i = 0; i < responseDTO.getExceptionDTOList().size(); i++) {
					ExceptionDTO dto = responseDTO.getExceptionDTOList().get(i);
					builder.append(dto.getErrorDescription());
					if (i < responseDTO.getExceptionDTOList().size() - 1) {
						builder.append("|");
					}

				}
				logger.info("Client Side Validation Errors");
				throw new Exception(builder.toString());

			}

		} catch (Exception exp) {
			logger.info("Client Side Errors",exp);
			throw new ShipmentFaultClientException(MessageFactory.createStaticMessage(exp.getMessage()), this);
		}

		return shipmentRequest;
	}

	private void validateUserAccessData(MuleMessage message, DespatchAdviceType despatchAdviceType) throws Exception {
		if(null!=despatchAdviceType.getDespatchSupplierParty()){
			String userName=despatchAdviceType.getDespatchSupplierParty().getUserName();
			if(StringUtils.isNotEmpty(userName)){
				message.setProperty("userName", userName, PropertyScope.OUTBOUND);
			}else{
				throw new Exception("Username is missing");
			}
			
			String password=despatchAdviceType.getDespatchSupplierParty().getPassword();
			if(StringUtils.isNotEmpty(password)){
				message.setProperty("password", password, PropertyScope.OUTBOUND);
			}else{
				throw new Exception("Password is missing");
			}
			
			String accessKey=despatchAdviceType.getDespatchSupplierParty().getAccessKey();
			if(StringUtils.isNotEmpty(accessKey)){
				message.setProperty("accessKey", accessKey, PropertyScope.OUTBOUND);
			}else{
				throw new Exception("Accesskey is missing");
			}
						
		}
	}

	/**
	 * Convert the payload into a DespatchAdvice
	 * 
	 * @param payload
	 * @return
	 * @throws TransformerException
	 */
	private DespatchAdviceType payloadAsDespatchAdvice(Object payload) throws TransformerException {
		try {
			if (payload == null) {
				throw new TransformerException(MessageFactory.createStaticMessage("empty payload"), this);
			} else if (payload instanceof DespatchAdviceType) {
				return (DespatchAdviceType) payload;
			} else if (payload instanceof String) {
				return payloadAsDespatchAdvice(new ByteArrayInputStream(((String) payload).getBytes(UTF_8)));
			} else if (payload instanceof byte[]) {
				return payloadAsDespatchAdvice(new ByteArrayInputStream((byte[]) payload));
			} else if (payload instanceof InputStream) {
				Unmarshaller unmarshaller = despatchAdviceJaxbContext.createUnmarshaller();

				Object unmarshalledObject = unmarshaller.unmarshal((InputStream) payload);
				if (unmarshalledObject == null) {
					return null;
				}
				if (!(unmarshalledObject instanceof JAXBElement)) {
					throw new Exception("invalid class " + unmarshalledObject.getClass().getName() + " from unmarshaller");
				}
				@SuppressWarnings("unchecked")
				JAXBElement<DespatchAdviceType> jaxbElement = (JAXBElement<DespatchAdviceType>) unmarshalledObject;
				return jaxbElement.getValue();
			} else {
				throw new TransformerException(MessageFactory.createStaticMessage("unexpected payload: " + payload.getClass().getName()),
						this);
			}
		} catch (Exception e) {
			throw new TransformerException(MessageFactory.createStaticMessage(e.getMessage()), e);
		}
	}

}
