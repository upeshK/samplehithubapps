/**
 * 
 */
package com.ebuilder.shipment.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * @author upesh
 *
 */
public class ValidationResultDTO implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = -6817522395158111100L;
	String status;
    List<ExceptionDTO> exceptionDTOs = new ArrayList<ExceptionDTO>();


    public List<ExceptionDTO> getExceptionDTOs() {
        return exceptionDTOs;
    }

    public void setExceptionDTOs(List<ExceptionDTO> exceptionDTOs) {
        this.exceptionDTOs = exceptionDTOs;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
