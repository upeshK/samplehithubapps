/**
 * 
 */
package com.ebuilder.shipment.validation;

import java.util.List;

import org.apache.log4j.Logger;

import com.ebuilder.ebtransport.ubleb.despatchadvice.AddressType;
import com.ebuilder.ebtransport.ubleb.despatchadvice.ContactType;
import com.ebuilder.ebtransport.ubleb.despatchadvice.CustomerPartyType;
import com.ebuilder.ebtransport.ubleb.despatchadvice.DespatchAdviceType;
import com.ebuilder.ebtransport.ubleb.despatchadvice.PartyType;
import com.ebuilder.shipment.validation.dto.CarrierResponseDTO;
import com.ebuilder.shipment.validation.dto.ExceptionDTO;
import com.ebuilder.util.Constants;
import com.ebuilder.util.StringUtils;
import com.ups.ship.ReturnServiceType;
import com.ups.ship.ShipAddressType;
import com.ups.ship.ShipPhoneType;
import com.ups.ship.ShipmentRequest;
import com.ups.ship.ShipmentType;
import com.ups.ship.ShipperType;

/**
 * @author upesh
 *
 */
public class ShipperValidator extends AbstractValidator {

	private static final Logger LOG = Logger.getLogger(ShipperValidator.class);

	public CarrierResponseDTO validate(DespatchAdviceType despatchAdvice, ShipmentRequest shipRequest, CarrierResponseDTO response) {
		LOG.info("Shipper Validation Started");
		if (StringUtils.isNotEmpty(despatchAdvice.getBillingParty())
				&& despatchAdvice.getBillingParty().equals(Constants.BillingParty.BILL_SHIPPER.getName())
				&& despatchAdvice.getOriginatorCustomerParty() != null) {
			final CustomerPartyType shipperPartyType = despatchAdvice.getOriginatorCustomerParty();
			validateShipper(shipperPartyType, despatchAdvice);

		} else if (StringUtils.isNotEmpty(despatchAdvice.getBillingParty())
				&& despatchAdvice.getBillingParty().equals(Constants.BillingParty.BILL_RECEIVER.getName())
				&& despatchAdvice.getDeliveryCustomerParty() != null) {
			final CustomerPartyType shipperPartyType = despatchAdvice.getDeliveryCustomerParty();
			validateShipper(shipperPartyType, despatchAdvice);

		} else if (StringUtils.isNotEmpty(despatchAdvice.getBillingParty())
				&& despatchAdvice.getBillingParty().equals(Constants.BillingParty.BILL_THIRD_PARTY.getName())
				&& despatchAdvice.getBillingThirdParty() != null) {
			final CustomerPartyType shipperPartyType = despatchAdvice.getBillingThirdParty();
			validateShipper(shipperPartyType, despatchAdvice);

		}

		return super.validate(despatchAdvice, shipRequest, response);
	}

	@Override
	public void populate(DespatchAdviceType despatchAdviceType, ShipmentRequest shipRequest) {

		if (StringUtils.isNotEmpty(despatchAdviceType.getBillingParty())) {

			if ((despatchAdviceType.getBillingParty().equals(Constants.BillingParty.BILL_SHIPPER.getName()))
					&& (despatchAdviceType.getOriginatorCustomerParty() != null)
					&& (despatchAdviceType.getOriginatorCustomerParty().getParty() != null)) {
				final CustomerPartyType shipmentPartyType = despatchAdviceType.getOriginatorCustomerParty();
				setShipper(shipmentPartyType, despatchAdviceType, shipRequest.getShipment());
			}

			if ((despatchAdviceType.getBillingParty().equals(Constants.BillingParty.BILL_RECEIVER.getName()))
					&& (despatchAdviceType.getDeliveryCustomerParty() != null)
					&& (despatchAdviceType.getDeliveryCustomerParty().getParty() != null)) {
				final CustomerPartyType shipmentPartyType = despatchAdviceType.getDeliveryCustomerParty();
				setReturnService(shipRequest.getShipment());
				setShipper(shipmentPartyType, despatchAdviceType, shipRequest.getShipment());
			}
			if ((despatchAdviceType.getBillingParty().equals(Constants.BillingParty.BILL_THIRD_PARTY.getName()))
					&& (despatchAdviceType.getBillingThirdParty() != null)
					&& (despatchAdviceType.getBillingThirdParty().getParty() != null)) {
				final CustomerPartyType shipmentPartyType = despatchAdviceType.getBillingThirdParty();
				setReturnService(shipRequest.getShipment());
				setShipper(shipmentPartyType, despatchAdviceType, shipRequest.getShipment());
			}
		}

	}

	private void setShipper(final CustomerPartyType shipmentPartyType, final DespatchAdviceType despatchAdvice,
			final ShipmentType shipmentType) {

		if (shipmentPartyType != null && shipmentPartyType.getParty() != null) {
			final ShipperType shipper = new ShipperType();
			final PartyType partyType = shipmentPartyType.getParty();
			if (shipmentPartyType.getParty().getPostalAddress() != null) {
				final com.ebuilder.ebtransport.ubleb.despatchadvice.AddressType addressType = shipmentPartyType.getParty()
						.getPostalAddress();
				String personName = partyType.getPerson();

				shipper.setName(partyType.getPartyName());

				 boolean isConsumer=(shipmentPartyType.getParty().getContact()!=null?(shipmentPartyType.getParty().getContact().getNote()!=null?(shipmentPartyType.getParty().getContact().getNote().equalsIgnoreCase("Consumer")):false):false);
				if (StringUtils.isNotEmpty(personName) && isConsumer ) {
					shipper.setName(personName);
				}

				// shipper.setName(partyType.getPartyName());

				// StringUtils.isEmpty(shipperPartyType.getParty().getPerson())

				if (null != shipmentPartyType.getParty() && StringUtils.isNotEmpty(shipmentPartyType.getParty().getPerson())) {
					shipper.setAttentionName(shipmentPartyType.getParty().getPerson());
				}

				
				  if (shipmentPartyType.getDeliveryContact() != null &&  StringUtils.isNotEmpty(shipmentPartyType.getDeliveryContact().getName())) {
				  shipper.setAttentionName(shipmentPartyType.getDeliveryContact().getName());
				  }
				

				if (despatchAdvice.getDespatchSupplierParty() != null
						&& StringUtils.isNotEmpty(despatchAdvice.getDespatchSupplierParty().getCustomerAssignedAccountID())) {
					shipper.setShipperNumber(despatchAdvice.getDespatchSupplierParty().getCustomerAssignedAccountID());
				}

				final ShipAddressType shipperAddress = new ShipAddressType();

				final List<String> addrLineList = shipperAddress.getAddressLine();
				addrLineList.add(addressType.getStreetName());
				
				//Fixed ASA-397:Add more address lines in UPS request
				if(StringUtils.isNotEmpty(addressType.getAdditionalStreetName())){
					addrLineList.add(1,addressType.getAdditionalStreetName().length()>35?addressType.getAdditionalStreetName().substring(0, 35):addressType.getAdditionalStreetName());
				}
				
				if(addressType.getAddressLine()!=null && !addressType.getAddressLine().isEmpty()){
					String addressLine3=addressType.getAddressLine().get(0);
					addrLineList.add(addressLine3.length()>35?addressLine3.substring(0, 35):addressLine3);
				}
	
				shipperAddress.setCity(addressType.getCityName());
				if (StringUtils.isNotEmpty(addressType.getPostalZone())) {
					shipperAddress.setPostalCode(addressType.getPostalZone());
				}
				if (StringUtils.isNotEmpty(addressType.getRegion())) {
					shipperAddress.setStateProvinceCode(addressType.getRegion());
				}
				if (addressType.getCountry() != null && StringUtils.isNotEmpty(addressType.getCountry().getIdentificationCode())) {
					shipperAddress.setCountryCode(addressType.getCountry().getIdentificationCode());
				}
				shipper.setAddress(shipperAddress);
			}
			String contactNo = getContactNo(partyType);
			if (StringUtils.isNotEmpty(contactNo)) {
				final ShipPhoneType shipperPhone = new ShipPhoneType();
				shipperPhone.setNumber(contactNo);
				shipper.setPhone(shipperPhone);
			}
			shipmentType.setShipper(shipper);
		}
	}

	private void setReturnService(final ShipmentType shipmentType) {
		ReturnServiceType returnServiceType = new ReturnServiceType();
		returnServiceType.setCode(Constants.UPS_PRINT_RETURN_LABEL);
		returnServiceType.setDescription(Constants.SHIPMENT_DESCRIPTION);
		shipmentType.setReturnService(returnServiceType);
	}

	/**
	 * if party type is consumer then the highest priority given to other
	 * communication field because other communication field holds the mobile no
	 * of the consumer
	 * 
	 * @param partyType
	 * @return String
	 */
	private String getContactNo(final PartyType partyType) {
		boolean consumerFlag = (partyType != null ? (partyType.getContact() != null ? (partyType.getContact().getNote() != null ? partyType
				.getContact().getNote().equalsIgnoreCase("Consumer") : false) : false) : false);
		String contactNo = null;
		if (partyType.getContact() != null) {
			final ContactType contactType = partyType.getContact();
			if (StringUtils.isNotEmpty(contactType.getTelephone())) {
				contactNo = contactType.getTelephone();
			}
			// TODO
			/*
			 * if(CarrierConnectorHelper.getInstance().isConsumer(partyType.
			 * getPartyID()) &&
			 * StringUtils.isNotEmpty(contactType.getOtherCommunication())){
			 * contactNo = contactType.getOtherCommunication().get(0); }
			 */

			if (consumerFlag && StringUtils.isNotEmpty(contactType.getOtherCommunication())) {
				contactNo = contactType.getOtherCommunication().get(0);
			}
		}
		return contactNo;
	}

	private void validateShipper(final CustomerPartyType shipperPartyType, final DespatchAdviceType despatchAdvice) {

		if (despatchAdvice.getDespatchSupplierParty() != null
				&& StringUtils.isEmpty(despatchAdvice.getDespatchSupplierParty().getCustomerAssignedAccountID())) {
			getExceptionHolder().add(new ExceptionDTO("Shipper Number Missing"));
		}

		if (despatchAdvice.getDespatchSupplierParty() != null
				&& StringUtils.isNotEmpty(despatchAdvice.getDespatchSupplierParty().getCustomerAssignedAccountID())
				&& despatchAdvice.getDespatchSupplierParty().getCustomerAssignedAccountID().length() != 6) {
			getExceptionHolder().add(new ExceptionDTO("Invalid Length for Shipper Number"));
		}

		if (shipperPartyType.getParty() != null) {
			final PartyType partyType = shipperPartyType.getParty();
			if (StringUtils.isEmpty(partyType.getPartyName())) {
				getExceptionHolder().add(new ExceptionDTO("Shipper Name Missing"));
			} else if (partyType.getPartyName().length() > 35) {
				String shipperName = partyType.getPartyName().substring(0, 35);
				partyType.setPartyName(shipperName);
			}

			if (partyType.getPostalAddress() != null) {
				final AddressType shipperAddr = partyType.getPostalAddress();
				validateAddress(Constants.SHIPPER_CONTEXT, shipperAddr);
				
				if (shipperPartyType.getDeliveryContact() != null) {
                    String siteID = partyType.getPartyID();
                    String personName = partyType.getPerson();
                    //shipperPartyType.getParty().getContact().getNote().equalsIgnoreCase("Consumer")
                    boolean isConsumer=(shipperPartyType.getParty().getContact()!=null?(shipperPartyType.getParty().getContact().getNote()!=null?(shipperPartyType.getParty().getContact().getNote().equalsIgnoreCase("Consumer")):false):false);
                    // Person name must be used as contact name for consumer sites.
                    if (StringUtils.isNotEmpty(personName) && isConsumer) {
                        shipperPartyType.getDeliveryContact().setName(personName);
                    }
                }

				if ( StringUtils.isNotEmpty(shipperAddr.getCountry()) 
						&& despatchAdvice.getDeliveryCustomerParty() != null 
						&& despatchAdvice.getDeliveryCustomerParty().getParty()!= null 
						&& despatchAdvice.getDeliveryCustomerParty().getParty().getPostalAddress()!=null
						&& despatchAdvice.getDeliveryCustomerParty().getParty().getPostalAddress().getCountry()!=null
						&& StringUtils.isNotEmpty(despatchAdvice.getDeliveryCustomerParty().getParty().getPostalAddress().getCountry().getIdentificationCode())
						&& shipperAddr!=null 
						&& shipperAddr.getCountry()!=null
						&& StringUtils.isNotEmpty(shipperAddr.getCountry().getIdentificationCode())
						&& (!shipperAddr.getCountry().getIdentificationCode().equals(despatchAdvice.getDeliveryCustomerParty().getParty().getPostalAddress().getCountry().getIdentificationCode()))						
						&& shipperPartyType.getDeliveryContact() != null && StringUtils.isEmpty(shipperPartyType.getDeliveryContact().getName()))
				{
					getExceptionHolder().add(new ExceptionDTO("Shipper Attention Name missing for International Shipment"));


				}	

				// if (shipperPartyType.getDeliveryContact() != null) {
				// String siteID = partyType.getPartyID();
				// String personName = partyType.getPerson();
				//
				// // Person name must be used as contact name for consumer
				// sites.
				// if (StringUtils.isNotEmpty(personName)) {
				// shipperPartyType.getDeliveryContact().setName(personName);
				// }
				// }

//				if (StringUtils.isNotEmpty(shipperAddr.getCountry())
//						&& despatchAdvice.getDeliveryCustomerParty() != null
//						&& despatchAdvice.getDeliveryCustomerParty().getParty() != null
//						&& despatchAdvice.getDeliveryCustomerParty().getParty().getPostalAddress() != null
//						&& despatchAdvice.getDeliveryCustomerParty().getParty().getPostalAddress().getCountry() != null
//						&& StringUtils.isNotEmpty(despatchAdvice.getDeliveryCustomerParty().getParty().getPostalAddress().getCountry()
//								.getIdentificationCode())
//						&& shipperAddr != null
//						&& shipperAddr.getCountry() != null
//						&& StringUtils.isNotEmpty(shipperAddr.getCountry().getIdentificationCode())
//						&& (!shipperAddr
//								.getCountry()
//								.getIdentificationCode()
//								.equals(despatchAdvice.getDeliveryCustomerParty().getParty().getPostalAddress().getCountry()
//										.getIdentificationCode()))
//						// && shipperPartyType.getDeliveryContact() != null &&
//						// StringUtils.isEmpty(shipperPartyType.getDeliveryContact().getName()
//						&& shipperPartyType.getParty().getContact() != null && shipperPartyType.getParty().getContact().getNote() != null
//						&& shipperPartyType.getParty().getContact().getNote().equalsIgnoreCase("Consumer")
//						&& StringUtils.isEmpty(shipperPartyType.getParty().getPerson()))
//
//				{
//					getExceptionHolder().add(new ExceptionDTO("Shipper Attention Name missing for International Shipment"));
//
//				}
			}
		}
	}

	private void validateAddress(final String context, final AddressType addressType) {

		if (addressType != null) {

			if (StringUtils.isEmpty(addressType.getStreetName())) {
				getExceptionHolder().add(new ExceptionDTO(context, "Address Missing"));
			} else if (addressType.getStreetName().length() > 35) {
				String addressLine = addressType.getStreetName().substring(0, 35);
				addressType.setStreetName(addressLine);
			}
		
			if (StringUtils.isEmpty(addressType.getCityName())) {
				getExceptionHolder().add(new ExceptionDTO(context, "City Missing"));
			} else if (addressType.getCityName().length() > 30) {
				String city = addressType.getCityName().substring(0, 30);
				addressType.setCityName(city);
			}

			if (addressType.getCountry() != null
					&& addressType.getCountry().getIdentificationCode() != null
					&& ((addressType.getCountry().getIdentificationCode().equals("US"))
							|| (addressType.getCountry().getIdentificationCode().equals("CA")) || (addressType.getCountry()
							.getIdentificationCode().equals("PR"))) && (StringUtils.isEmpty(addressType.getPostalZone()))) {
				getExceptionHolder().add(new ExceptionDTO(context, "Postal Code Missing For CA/US/PR"));

			}

			if (StringUtils.isNotEmpty(addressType.getPostalZone()) && addressType.getPostalZone().length() > 9) {
				String postalZone = addressType.getPostalZone().substring(0, 9);
				addressType.setPostalZone(postalZone);
			}

			if (addressType.getCountry() != null
					&& addressType.getCountry().getIdentificationCode() != null
					&& ((addressType.getCountry().getIdentificationCode().equals("US")) || (addressType.getCountry()
							.getIdentificationCode().equals("CA"))) && (StringUtils.isEmpty(addressType.getRegion()))) {
				getExceptionHolder().add(new ExceptionDTO(context, "State/Province Missing For US/CA"));
			}

			if (addressType.getCountry() != null && StringUtils.isEmpty(addressType.getCountry().getIdentificationCode())) {
				getExceptionHolder().add(new ExceptionDTO(context, "Country Code Missing"));
			}

		}
	}

}
