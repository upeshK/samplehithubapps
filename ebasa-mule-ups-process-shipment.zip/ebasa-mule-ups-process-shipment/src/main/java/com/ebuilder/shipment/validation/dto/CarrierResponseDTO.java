/**
 * Copyright 2011, Marakanda Marknadsplats AB
 * All rights reserved
 *
 * This is UNPUBLISHED PROPRIETARY SOURCE CODE
 * of Marakanda Marknadsplats AB;
 * the contents of this file may not be disclosed to third parties,
 * copied or duplicated in any form, in whole or in part,
 * without the prior written permission of Marakanda Marknadsplats AB.
 *
 * Author: Nuwan Walisundara
 * Created: Jun 8, 2011, 10:33:16 AM
 */
package com.ebuilder.shipment.validation.dto;

import java.io.Serializable;
import java.util.List;



public class CarrierResponseDTO implements Serializable {

	/**
	 * 
	 */
    private static final long serialVersionUID = 3427432684975143092L;
    boolean isFail;
    boolean isValidationFail;
    private String consignmentNo;
    private List<DocumentDTO> documentList;
    private List<ExceptionDTO> exceptionDTOList;
    private String FailedReasonID;
    //private ErrorHolder errorHolder;
    
    
    
  /*  public ErrorHolder getErrorHolder() {
		return errorHolder;
	}

	public void setErrorHolder(ErrorHolder errorHolder) {
		this.errorHolder = errorHolder;
	}*/

	public List<ExceptionDTO> getExceptionDTOList() {
		return exceptionDTOList;
	}

	public void setExceptionDTOList(List<ExceptionDTO> exceptionDTOList) {
		this.exceptionDTOList = exceptionDTOList;
	}

	public boolean isFail() {
        return isFail;
    }

    public void setFail(boolean isFail) {
        this.isFail = isFail;
    }

    public String getConsignmentNo() {
        return consignmentNo;
    }

    public void setConsignmentNo(String consignmentNo) {
        this.consignmentNo = consignmentNo;
    }

    public List<DocumentDTO> getDocumentList() {
        return documentList;
    }

    public void setDocumentList(List<DocumentDTO> documentList) {
        this.documentList = documentList;
    }

	public boolean isValidationFail() {
		return isValidationFail;
	}

	public void setValidationFail(boolean isValidationFail) {
		this.isValidationFail = isValidationFail;
		if(isValidationFail){
			this.isFail = Boolean.TRUE;
		}
		
	}

	public String getFailedReasonID() {
		return FailedReasonID;
	}

	public void setFailedReasonID(String failedReasonID) {
		FailedReasonID = failedReasonID;
	}
    
}