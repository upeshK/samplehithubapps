/**
 * 
 */
package com.ebuilder.shipment.validation;

import java.util.List;

import org.apache.log4j.Logger;

import com.ebuilder.ebtransport.ubleb.despatchadvice.DespatchAdviceType;
import com.ebuilder.shipment.validation.dto.CarrierResponseDTO;
import com.ebuilder.util.Constants;
import com.ebuilder.util.StringUtils;
import com.ups.ship.BillShipperType;
import com.ups.ship.PaymentInfoType;
import com.ups.ship.ShipmentChargeType;
import com.ups.ship.ShipmentRequest;
import com.ups.ship.ShipmentType;

/**
 * @author upesh
 *
 */
public class PaymentInfoValidator extends AbstractValidator {

	private static final Logger LOG = Logger.getLogger(PaymentInfoValidator.class);

	public CarrierResponseDTO validate(DespatchAdviceType despatchAdvice, ShipmentRequest shipRequest, CarrierResponseDTO response) {
		// No any Validation here
		return super.validate(despatchAdvice, shipRequest, response);
	}

	@Override
	public void populate(DespatchAdviceType despatchAdviceType, ShipmentRequest shipRequest) {
		setPaymentInformation(despatchAdviceType, shipRequest.getShipment());
	}

	private void setPaymentInformation(final DespatchAdviceType despatchAdvice, final ShipmentType shipmentType) {
		if (despatchAdvice.getDespatchSupplierParty() != null
				&& StringUtils.isNotEmpty(despatchAdvice.getDespatchSupplierParty().getCustomerAssignedAccountID())) {
			final PaymentInfoType payInfo = new PaymentInfoType();
			final ShipmentChargeType shipmentCharge = new ShipmentChargeType();
			shipmentCharge.setType(Constants.TRANSPORTATION);
			final BillShipperType billShipper = new BillShipperType();
			billShipper.setAccountNumber(despatchAdvice.getDespatchSupplierParty().getCustomerAssignedAccountID());
			shipmentCharge.setBillShipper(billShipper);
			final List<ShipmentChargeType> shipmentCharges = payInfo.getShipmentCharge();
			shipmentCharges.add(shipmentCharge);
			shipmentType.setPaymentInformation(payInfo);
		}
	}

}
