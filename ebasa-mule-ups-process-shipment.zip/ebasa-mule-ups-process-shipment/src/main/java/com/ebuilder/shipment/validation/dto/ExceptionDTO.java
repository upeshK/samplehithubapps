package com.ebuilder.shipment.validation.dto;

import java.io.Serializable;

import com.ebuilder.util.StringUtils;



public class ExceptionDTO implements Serializable{

	private static final long serialVersionUID = -1477588852170890496L;

	private String errorCode;
	private String errorDescription;
	
	public ExceptionDTO(){
		
	}

	public ExceptionDTO(final String errorDescription){		
		this.errorDescription=errorDescription;
	}	
	
	
	public ExceptionDTO(final String context,final String desc){
		if(StringUtils.isNotEmpty(context) && StringUtils.isNotEmpty(desc)){
			final StringBuilder stringBuilder=new StringBuilder();
			this.errorDescription=stringBuilder.append(context).append(" ").append(desc).append(" ").toString();
		}

	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(final String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorDescription() {

		return errorDescription;
	}

	public void setErrorDescription(final String errorDescription) {
		this.errorDescription = errorDescription;
	}

}
