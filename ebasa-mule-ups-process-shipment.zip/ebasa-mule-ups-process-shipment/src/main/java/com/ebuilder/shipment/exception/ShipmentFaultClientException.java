/**
 * 
 */
package com.ebuilder.shipment.exception;

import org.mule.config.i18n.Message;
import org.mule.transformer.AbstractTransformer;



/**
 * @author upesh
 *
 */
public class ShipmentFaultClientException extends ShipmentFaultException  {


	private static final long serialVersionUID = 1430884159999058534L;

	public ShipmentFaultClientException(Message message, Throwable cause) {
		super(message, cause);
	}
	
	public ShipmentFaultClientException(Message message, AbstractTransformer transformer) {
		super(message, transformer);
	}
}

