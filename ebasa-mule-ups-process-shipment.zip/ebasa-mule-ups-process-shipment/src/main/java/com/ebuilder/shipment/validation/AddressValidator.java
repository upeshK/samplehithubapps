/**
 * 
 */
package com.ebuilder.shipment.validation;

import org.apache.log4j.Logger;

import com.ebuilder.ebtransport.ubleb.despatchadvice.AddressType;
import com.ebuilder.ebtransport.ubleb.despatchadvice.DespatchAdviceType;
import com.ebuilder.shipment.validation.dto.CarrierResponseDTO;
import com.ebuilder.shipment.validation.dto.ExceptionDTO;
import com.ebuilder.util.StringUtils;
import com.ups.ship.ShipmentRequest;

/**
 * @author upesh
 *
 */
public class AddressValidator extends AbstractValidator {
	private static final Logger LOG = Logger.getLogger(AddressValidator.class);
	private String context;
	private AddressType addressType;

	public CarrierResponseDTO validate(DespatchAdviceType despatchAdvice, ShipmentRequest shipRequest, CarrierResponseDTO response) {
		LOG.info("Address Validation Started");
		if (addressType != null) {

			if (StringUtils.isEmpty(addressType.getStreetName())) {
				getExceptionHolder().add(new ExceptionDTO(context, "Address Missing"));
			} else if (addressType.getStreetName().length() > 35) {
				String addressLine = addressType.getStreetName().substring(0, 35);
				addressType.setStreetName(addressLine);
			}
			if (StringUtils.isEmpty(addressType.getCityName())) {
				getExceptionHolder().add(new ExceptionDTO(context, "City Missing"));
			} else if (addressType.getCityName().length() > 30) {
				String city = addressType.getCityName().substring(0, 30);
				addressType.setCityName(city);
			}

			if (addressType.getCountry() != null
					&& addressType.getCountry().getIdentificationCode() != null
					&& ((addressType.getCountry().getIdentificationCode().equals("US"))
							|| (addressType.getCountry().getIdentificationCode().equals("CA")) || (addressType.getCountry()
							.getIdentificationCode().equals("PR"))) && (StringUtils.isEmpty(addressType.getPostalZone()))) {
				getExceptionHolder().add(new ExceptionDTO(context, "Postal Code Missing For CA/US/PR"));

			}

			if (StringUtils.isNotEmpty(addressType.getPostalZone()) && addressType.getPostalZone().length() > 9) {
				String postalZone = addressType.getPostalZone().substring(0, 9);
				addressType.setPostalZone(postalZone);
			}

			if (addressType.getCountry() != null
					&& addressType.getCountry().getIdentificationCode() != null
					&& ((addressType.getCountry().getIdentificationCode().equals("US")) || (addressType.getCountry()
							.getIdentificationCode().equals("CA"))) && (StringUtils.isEmpty(addressType.getRegion()))) {
				getExceptionHolder().add(new ExceptionDTO(context, "State/Province Missing For US/CA"));
			}

			if (addressType.getCountry() != null && StringUtils.isEmpty(addressType.getCountry().getIdentificationCode())) {
				getExceptionHolder().add(new ExceptionDTO(context, "Country Code Missing"));
			}

		}

		return super.validate(despatchAdvice, shipRequest, response);
	}

	@Override
	public void populate(DespatchAdviceType despatchAdviceType, ShipmentRequest shipRequest) {

	}

	public String getContext() {
		return context;
	}

	public void setContext(String context) {
		this.context = context;
	}

	public AddressType getAddressType() {
		return addressType;
	}

	public void setAddressType(AddressType addressType) {
		this.addressType = addressType;
	}

}
