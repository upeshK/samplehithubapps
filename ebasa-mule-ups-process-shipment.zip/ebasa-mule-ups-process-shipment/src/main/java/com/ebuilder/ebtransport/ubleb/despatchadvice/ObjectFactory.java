
package com.ebuilder.ebtransport.ubleb.despatchadvice;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.ebuilder.ebtransport.ubleb.despatchadvice package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _DespatchAdvice_QNAME = new QName("urn:com:ebuilder:ebtransport:ubleb:despatchadvice", "DespatchAdvice");
    private final static QName _Consignment_QNAME = new QName("urn:com:ebuilder:ebtransport:ubleb:despatchadvice", "Consignment");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.ebuilder.ebtransport.ubleb.despatchadvice
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link GoodsItemType }
     * 
     */
    public GoodsItemType createGoodsItemType() {
        return new GoodsItemType();
    }

    /**
     * Create an instance of {@link DespatchAdviceType }
     * 
     */
    public DespatchAdviceType createDespatchAdviceType() {
        return new DespatchAdviceType();
    }

    /**
     * Create an instance of {@link ConsignmentType }
     * 
     */
    public ConsignmentType createConsignmentType() {
        return new ConsignmentType();
    }

    /**
     * Create an instance of {@link AvailbilityType }
     * 
     */
    public AvailbilityType createAvailbilityType() {
        return new AvailbilityType();
    }

    /**
     * Create an instance of {@link CountryType }
     * 
     */
    public CountryType createCountryType() {
        return new CountryType();
    }

    /**
     * Create an instance of {@link PartyType }
     * 
     */
    public PartyType createPartyType() {
        return new PartyType();
    }

    /**
     * Create an instance of {@link ParamType }
     * 
     */
    public ParamType createParamType() {
        return new ParamType();
    }

    /**
     * Create an instance of {@link PeriodType }
     * 
     */
    public PeriodType createPeriodType() {
        return new PeriodType();
    }

    /**
     * Create an instance of {@link SignatureType }
     * 
     */
    public SignatureType createSignatureType() {
        return new SignatureType();
    }

    /**
     * Create an instance of {@link DocumentReferenceType }
     * 
     */
    public DocumentReferenceType createDocumentReferenceType() {
        return new DocumentReferenceType();
    }

    /**
     * Create an instance of {@link DespatchLineType }
     * 
     */
    public DespatchLineType createDespatchLineType() {
        return new DespatchLineType();
    }

    /**
     * Create an instance of {@link ItemInstanceType }
     * 
     */
    public ItemInstanceType createItemInstanceType() {
        return new ItemInstanceType();
    }

    /**
     * Create an instance of {@link SupplierPartyType }
     * 
     */
    public SupplierPartyType createSupplierPartyType() {
        return new SupplierPartyType();
    }

    /**
     * Create an instance of {@link DeliveryType }
     * 
     */
    public DeliveryType createDeliveryType() {
        return new DeliveryType();
    }

    /**
     * Create an instance of {@link ParamsType }
     * 
     */
    public ParamsType createParamsType() {
        return new ParamsType();
    }

    /**
     * Create an instance of {@link ItemType }
     * 
     */
    public ItemType createItemType() {
        return new ItemType();
    }

    /**
     * Create an instance of {@link CustomerPartyType }
     * 
     */
    public CustomerPartyType createCustomerPartyType() {
        return new CustomerPartyType();
    }

    /**
     * Create an instance of {@link LocationType }
     * 
     */
    public LocationType createLocationType() {
        return new LocationType();
    }

    /**
     * Create an instance of {@link ShipmentStageType }
     * 
     */
    public ShipmentStageType createShipmentStageType() {
        return new ShipmentStageType();
    }

    /**
     * Create an instance of {@link DespatchType }
     * 
     */
    public DespatchType createDespatchType() {
        return new DespatchType();
    }

    /**
     * Create an instance of {@link AddressType }
     * 
     */
    public AddressType createAddressType() {
        return new AddressType();
    }

    /**
     * Create an instance of {@link DocumentType }
     * 
     */
    public DocumentType createDocumentType() {
        return new DocumentType();
    }

    /**
     * Create an instance of {@link AllowanceChargeType }
     * 
     */
    public AllowanceChargeType createAllowanceChargeType() {
        return new AllowanceChargeType();
    }

    /**
     * Create an instance of {@link ContactType }
     * 
     */
    public ContactType createContactType() {
        return new ContactType();
    }

    /**
     * Create an instance of {@link ShippingDocsType }
     * 
     */
    public ShippingDocsType createShippingDocsType() {
        return new ShippingDocsType();
    }

    /**
     * Create an instance of {@link ShipmentType }
     * 
     */
    public ShipmentType createShipmentType() {
        return new ShipmentType();
    }

    /**
     * Create an instance of {@link TransportHandlingUnitType }
     * 
     */
    public TransportHandlingUnitType createTransportHandlingUnitType() {
        return new TransportHandlingUnitType();
    }

    /**
     * Create an instance of {@link GoodsItemType.Dimension }
     * 
     */
    public GoodsItemType.Dimension createGoodsItemTypeDimension() {
        return new GoodsItemType.Dimension();
    }

    /**
     * Create an instance of {@link DespatchAdviceType.PickupInformation }
     * 
     */
    public DespatchAdviceType.PickupInformation createDespatchAdviceTypePickupInformation() {
        return new DespatchAdviceType.PickupInformation();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DespatchAdviceType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:com:ebuilder:ebtransport:ubleb:despatchadvice", name = "DespatchAdvice")
    public JAXBElement<DespatchAdviceType> createDespatchAdvice(DespatchAdviceType value) {
        return new JAXBElement<DespatchAdviceType>(_DespatchAdvice_QNAME, DespatchAdviceType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ConsignmentType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:com:ebuilder:ebtransport:ubleb:despatchadvice", name = "Consignment")
    public JAXBElement<ConsignmentType> createConsignment(ConsignmentType value) {
        return new JAXBElement<ConsignmentType>(_Consignment_QNAME, ConsignmentType.class, null, value);
    }

}
