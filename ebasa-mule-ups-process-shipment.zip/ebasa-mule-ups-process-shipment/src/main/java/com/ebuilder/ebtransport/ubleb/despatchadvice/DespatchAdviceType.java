
package com.ebuilder.ebtransport.ubleb.despatchadvice;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DespatchAdviceType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DespatchAdviceType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="SCSVersionID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="IssueDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DespatchAdviceTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DespatchSupplierParty" type="{urn:com:ebuilder:ebtransport:ubleb:despatchadvice}SupplierPartyType"/>
 *         &lt;element name="DeliveryCustomerParty" type="{urn:com:ebuilder:ebtransport:ubleb:despatchadvice}CustomerPartyType"/>
 *         &lt;element name="OriginatorCustomerParty" type="{urn:com:ebuilder:ebtransport:ubleb:despatchadvice}CustomerPartyType" minOccurs="0"/>
 *         &lt;element name="BillingThirdParty" type="{urn:com:ebuilder:ebtransport:ubleb:despatchadvice}CustomerPartyType" minOccurs="0"/>
 *         &lt;element name="BillingCustomerParty" type="{urn:com:ebuilder:ebtransport:ubleb:despatchadvice}CustomerPartyType" minOccurs="0"/>
 *         &lt;element name="PickupInformation" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="Availbility" type="{urn:com:ebuilder:ebtransport:ubleb:despatchadvice}AvailbilityType" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="DespatchLine" type="{urn:com:ebuilder:ebtransport:ubleb:despatchadvice}DespatchLineType" maxOccurs="unbounded"/>
 *         &lt;element name="Sender" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Receiver" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BillingParty" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;enumeration value="ORIGINATORCUSTOMER"/>
 *               &lt;enumeration value="DELIVERYCUSTOMER"/>
 *               &lt;enumeration value="BILLINGTHIRDPARTY"/>
 *               &lt;enumeration value="BILLINGCUSTOMER"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="DeliveryServicePoint" type="{urn:com:ebuilder:ebtransport:ubleb:despatchadvice}AddressType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DespatchAdviceType", propOrder = {
    "scsVersionID",
    "id",
    "issueDate",
    "despatchAdviceTypeCode",
    "despatchSupplierParty",
    "deliveryCustomerParty",
    "originatorCustomerParty",
    "billingThirdParty",
    "billingCustomerParty",
    "pickupInformation",
    "despatchLine",
    "sender",
    "receiver",
    "billingParty",
    "deliveryServicePoint"
})
@XmlRootElement(name="DespatchAdvice")
public class DespatchAdviceType
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "SCSVersionID")
    protected String scsVersionID;
    @XmlElement(name = "ID", required = true)
    protected String id;
    @XmlElement(name = "IssueDate")
    protected String issueDate;
    @XmlElement(name = "DespatchAdviceTypeCode")
    protected String despatchAdviceTypeCode;
    @XmlElement(name = "DespatchSupplierParty", required = true)
    protected SupplierPartyType despatchSupplierParty;
    @XmlElement(name = "DeliveryCustomerParty", required = true)
    protected CustomerPartyType deliveryCustomerParty;
    @XmlElement(name = "OriginatorCustomerParty")
    protected CustomerPartyType originatorCustomerParty;
    @XmlElement(name = "BillingThirdParty")
    protected CustomerPartyType billingThirdParty;
    @XmlElement(name = "BillingCustomerParty")
    protected CustomerPartyType billingCustomerParty;
    @XmlElement(name = "PickupInformation")
    protected DespatchAdviceType.PickupInformation pickupInformation;
    @XmlElement(name = "DespatchLine", required = true)
    protected List<DespatchLineType> despatchLine;
    @XmlElement(name = "Sender")
    protected String sender;
    @XmlElement(name = "Receiver")
    protected String receiver;
    @XmlElement(name = "BillingParty")
    protected String billingParty;
    @XmlElement(name = "DeliveryServicePoint")
    protected AddressType deliveryServicePoint;

    /**
     * Gets the value of the scsVersionID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSCSVersionID() {
        return scsVersionID;
    }

    /**
     * Sets the value of the scsVersionID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSCSVersionID(String value) {
        this.scsVersionID = value;
    }

    /**
     * Gets the value of the id property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getID() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setID(String value) {
        this.id = value;
    }

    /**
     * Gets the value of the issueDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIssueDate() {
        return issueDate;
    }

    /**
     * Sets the value of the issueDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIssueDate(String value) {
        this.issueDate = value;
    }

    /**
     * Gets the value of the despatchAdviceTypeCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDespatchAdviceTypeCode() {
        return despatchAdviceTypeCode;
    }

    /**
     * Sets the value of the despatchAdviceTypeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDespatchAdviceTypeCode(String value) {
        this.despatchAdviceTypeCode = value;
    }

    /**
     * Gets the value of the despatchSupplierParty property.
     * 
     * @return
     *     possible object is
     *     {@link SupplierPartyType }
     *     
     */
    public SupplierPartyType getDespatchSupplierParty() {
        return despatchSupplierParty;
    }

    /**
     * Sets the value of the despatchSupplierParty property.
     * 
     * @param value
     *     allowed object is
     *     {@link SupplierPartyType }
     *     
     */
    public void setDespatchSupplierParty(SupplierPartyType value) {
        this.despatchSupplierParty = value;
    }

    /**
     * Gets the value of the deliveryCustomerParty property.
     * 
     * @return
     *     possible object is
     *     {@link CustomerPartyType }
     *     
     */
    public CustomerPartyType getDeliveryCustomerParty() {
        return deliveryCustomerParty;
    }

    /**
     * Sets the value of the deliveryCustomerParty property.
     * 
     * @param value
     *     allowed object is
     *     {@link CustomerPartyType }
     *     
     */
    public void setDeliveryCustomerParty(CustomerPartyType value) {
        this.deliveryCustomerParty = value;
    }

    /**
     * Gets the value of the originatorCustomerParty property.
     * 
     * @return
     *     possible object is
     *     {@link CustomerPartyType }
     *     
     */
    public CustomerPartyType getOriginatorCustomerParty() {
        return originatorCustomerParty;
    }

    /**
     * Sets the value of the originatorCustomerParty property.
     * 
     * @param value
     *     allowed object is
     *     {@link CustomerPartyType }
     *     
     */
    public void setOriginatorCustomerParty(CustomerPartyType value) {
        this.originatorCustomerParty = value;
    }

    /**
     * Gets the value of the billingThirdParty property.
     * 
     * @return
     *     possible object is
     *     {@link CustomerPartyType }
     *     
     */
    public CustomerPartyType getBillingThirdParty() {
        return billingThirdParty;
    }

    /**
     * Sets the value of the billingThirdParty property.
     * 
     * @param value
     *     allowed object is
     *     {@link CustomerPartyType }
     *     
     */
    public void setBillingThirdParty(CustomerPartyType value) {
        this.billingThirdParty = value;
    }

    /**
     * Gets the value of the billingCustomerParty property.
     * 
     * @return
     *     possible object is
     *     {@link CustomerPartyType }
     *     
     */
    public CustomerPartyType getBillingCustomerParty() {
        return billingCustomerParty;
    }

    /**
     * Sets the value of the billingCustomerParty property.
     * 
     * @param value
     *     allowed object is
     *     {@link CustomerPartyType }
     *     
     */
    public void setBillingCustomerParty(CustomerPartyType value) {
        this.billingCustomerParty = value;
    }

    /**
     * Gets the value of the pickupInformation property.
     * 
     * @return
     *     possible object is
     *     {@link DespatchAdviceType.PickupInformation }
     *     
     */
    public DespatchAdviceType.PickupInformation getPickupInformation() {
        return pickupInformation;
    }

    /**
     * Sets the value of the pickupInformation property.
     * 
     * @param value
     *     allowed object is
     *     {@link DespatchAdviceType.PickupInformation }
     *     
     */
    public void setPickupInformation(DespatchAdviceType.PickupInformation value) {
        this.pickupInformation = value;
    }

    /**
     * Gets the value of the despatchLine property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the despatchLine property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDespatchLine().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DespatchLineType }
     * 
     * 
     */
    public List<DespatchLineType> getDespatchLine() {
        if (despatchLine == null) {
            despatchLine = new ArrayList<DespatchLineType>();
        }
        return this.despatchLine;
    }

    /**
     * Gets the value of the sender property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSender() {
        return sender;
    }

    /**
     * Sets the value of the sender property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSender(String value) {
        this.sender = value;
    }

    /**
     * Gets the value of the receiver property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiver() {
        return receiver;
    }

    /**
     * Sets the value of the receiver property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiver(String value) {
        this.receiver = value;
    }

    /**
     * Gets the value of the billingParty property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBillingParty() {
        return billingParty;
    }

    /**
     * Sets the value of the billingParty property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBillingParty(String value) {
        this.billingParty = value;
    }

    /**
     * Gets the value of the deliveryServicePoint property.
     * 
     * @return
     *     possible object is
     *     {@link AddressType }
     *     
     */
    public AddressType getDeliveryServicePoint() {
        return deliveryServicePoint;
    }

    /**
     * Sets the value of the deliveryServicePoint property.
     * 
     * @param value
     *     allowed object is
     *     {@link AddressType }
     *     
     */
    public void setDeliveryServicePoint(AddressType value) {
        this.deliveryServicePoint = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Availbility" type="{urn:com:ebuilder:ebtransport:ubleb:despatchadvice}AvailbilityType" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "availbility"
    })
    public static class PickupInformation
        implements Serializable
    {

        private final static long serialVersionUID = 1L;
        @XmlElement(name = "Availbility")
        protected AvailbilityType availbility;

        /**
         * Gets the value of the availbility property.
         * 
         * @return
         *     possible object is
         *     {@link AvailbilityType }
         *     
         */
        public AvailbilityType getAvailbility() {
            return availbility;
        }

        /**
         * Sets the value of the availbility property.
         * 
         * @param value
         *     allowed object is
         *     {@link AvailbilityType }
         *     
         */
        public void setAvailbility(AvailbilityType value) {
            this.availbility = value;
        }

    }

}
