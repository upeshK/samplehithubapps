@javax.xml.bind.annotation.XmlSchema(namespace = "urn:com:ebuilder:ebtransport:ubleb:despatchadvice", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.ebuilder.ebtransport.ubleb.despatchadvice;
