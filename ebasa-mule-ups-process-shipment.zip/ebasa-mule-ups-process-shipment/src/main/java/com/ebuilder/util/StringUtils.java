/**
 * 
 */
package com.ebuilder.util;

import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Date;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Map;

public class StringUtils
{
    /**
     * An empty string.
     */
    public static final String EMPTY_STRING = "";

    /**
     * Line feed character.
     */
    public static final char LINE_FEED = '\r';    // (aka u000A);

    /**
     * A String 0.
     */
    private static final String STRING_ZERO = "0";

    /**
     * The default length for a chomp()
     */
    private static int chompLength = 32;

    public static int getChompLength()
    {
        return chompLength;
    }

    public static void setChompLength(int chompLength)
    {
        StringUtils.chompLength = chompLength;
    }

    /**
     * Returns true if null or trims to an empty string.
     *
     * @param s ...
     * @return boolean ...
     * @deprecated Use #isEmpty() or #isNotEmpty() instead
     */
    public static boolean isBlank(String s)
    {
        return ((null == s) || (EMPTY_STRING.equals(s.trim())));
    }

    /**
     * Returns true if null or zero.
     *
     * @param key ...
     * @return boolean ...
     * @deprecated Use #isEmpty() or #isNotEmpty() instead
     */
    public static boolean isBlank(Integer key)
    {
        return ((null == key) || (0 == key.intValue()));
    }

    /**
     * Returns true if null or trims to an empty string.
     *
     * @param s ...
     * @return boolean ...
     * @deprecated Use #isEmpty() or #isNotEmpty() instead
     */
    public static boolean isBlankValue(String s)
    {
        if (null == s) {
            return true;
        }
        String str = s.trim();
        return ((EMPTY_STRING.equals(str)) || (STRING_ZERO.equals(str)));
    }

    /**
     * Returns null or a trimmed uppercase string.
     *
     * @param string ...
     * @return String ...
     */
    public static String toUpperOrNull(String string)
    {
        if (null != string) {
            return string.toUpperCase().trim();
        }
        return null;
    }

    /**
     * Returns the count left characters from string str
     *
     * @param str   ...
     * @param count ...
     * @return ...
     */
    public static String left(String str, int count)
    {
        if ((str != null) && (str.length() > count)) {
            return str.substring(0, count);
        }
        return str;
    }

    /**
     * Chomp the string to count characters long with "..." at the end
     * to indicate that a chomp was made. Use whatever property chompLength is set to
     *
     * @param str ...
     * @return ...
     */
    public static String chomp(String str)
    {
        return chomp(str, chompLength);
    }

    /**
     * Chomp the string to count characters long with "..." at the end
     * to indicate that a chomp was made.
     *
     * @param str   ...
     * @param count ...
     * @return ...
     */
    public static String chomp(String str, int count)
    {
        if ((str != null) && (count > 3) && (str.length() > (count - 3))) {
            return left(str, count - 3) + "...";
        }
        else {
            return str;
        }
    }

    /**
     * Add a specific character until the String is a specific length
     *
     * @param str The original string, if this String object is null this method will return null
     * @param ch  The character to add at the end of the string
     * @param len The length the string should be
     * @return A new string with a number of characters appended at the end so it gets the specified length
     */
    public static String addCharUntilLength(String str, char ch, long len)
    {
        if (str != null) {
            StringBuffer sb = new StringBuffer(str);
            for (int i = str.length(); i < len; i++) {
                sb.append(ch);
            }
            return sb.toString();
        }
        else {
            return null;
        }
    }

    /**
     * Inserts a specific character in the beginning of string until the String is a specific length
     *
     * @param str The original string, if this String object is null this method will return null
     * @param ch  The character to insert at the beginning of the string
     * @param len The length the string should be
     * @return A new string with a number of characters inserted at the beginning so it gets the specified length
     */
    public static String insertCharUntilLength(String str, char ch, long len)
    {
        if (str != null) {
            StringBuffer sb = new StringBuffer(str);
            for (int i = str.length(); i < len; i++) {
                sb.insert(0, ch);
            }
            return sb.toString();
        }
        else {
            return null;
        }
    }

    /**
     * If the specified postfix exists at the end of the string shorten the string at the
     * end with the length of the postfix. It will try to remove the postfix until it no longer
     * matches the end of the string.
     *
     * @param str     The string to shorten
     * @param postfix The string will be shorten as long as the string end matches this prefix
     * @return The shorten string
     */
    public static String removeFromEnd(String str, String postfix)
    {
        if (str != null) {
            StringBuffer sb = new StringBuffer(str);
            while (sb.toString().endsWith(postfix)) {
                sb.setLength(sb.length() - postfix.length());
            }
            return sb.toString();
        }
        else {
            return null;
        }
    }

  /*  public static String toString(Object obj)
    {
        return toString(obj, "");
    }*/

    public static boolean isEmpty(Object obj)
    {
        if(obj == null) {
            return true;
        }
        else if (obj instanceof String) {
            return ((String)obj).trim().length() <= 0;
        }
        else if (obj instanceof Date) {
            return ((Date)obj).getTime() <= 0;
        }
        else if (obj.getClass().isArray()) {
            return Array.getLength(obj) <= 0;
        }
        else if (obj instanceof Collection) {
            return ((Collection) obj).size() <= 0;
        }
        else if (obj instanceof Iterator) {
            return !((Iterator) obj).hasNext();
        }
        else if (obj instanceof Map) {
            return ((Map) obj).entrySet().size() <= 0;
        }
        else if (obj instanceof Enumeration) {
            return !((Enumeration) obj).hasMoreElements();
        }
        return false; // Object not null!
    }

    public static boolean isNotEmpty(Object obj)
    {
        return !isEmpty(obj);
    }
    
    /** if a string is actually a numeric
    *
    * @param str
    * @return boolean
    * @throws UnsupportedEncodingException
    */
   public   static   boolean   isNumber(String   str)   {
       //   +     -     digits   and   point   is   allowed
       return   java.util.regex.Pattern.matches("^[-+0-9.]*$",   str.trim());
   }
}


