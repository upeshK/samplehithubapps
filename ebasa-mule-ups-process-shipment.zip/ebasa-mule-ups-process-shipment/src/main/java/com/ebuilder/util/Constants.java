/**
 * 
 */
package com.ebuilder.util;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

/**
 * @author upesh
 *
 */
public class Constants {
	
	public static final String UPS_PRINT_RETURN_LABEL="9";
	public static final String SHIPMENT_DESCRIPTION="Mobile phones";
	public static final String TRANSPORTATION="01";
	public static final String CUSTOMER_SUPPLIED_PACKAGE = "02";
	public static final String UNIT_OF_MEASURE_KILOGRAM = "KGS";
	public static final String UPS_LABEL_IMAGE_FORMAT="GIF";
	public static final String SUCCESS_RESPONSE = "SUCCESS";
	public static final String FAILURE_RESPONSE = "FAIL";
	public static final String SHIP_TO_CONTEXT="Ship From";
	public static final String SHIP_FROM_CONTEXT="Ship To";
	public static final Double UPS_DEFAULT_WAIGHT=0.1;
	public static final String STR_UPS_DEFAULT_WAIGHT="0.1";
	public static final String SHIPPER_CONTEXT="Shipper";
	public static final String UPS_SUCCESS_RESPONSE = "Success";
	public static final String AWB_LABEL="AWB";
	public static final boolean MESSAGE_FAILED = true;
	public static final String NON_VALIDATE_ADDRESS = "nonvalidate";
	
	public enum BillingParty {

		BILL_SHIPPER("ORIGINATORCUSTOMER"), BILL_RECEIVER("DELIVERYCUSTOMER"), BILL_THIRD_PARTY("BILLINGTHIRDPARTY"), UNKNOWN("UNKNOWN");

		private final String name;

		private static Map<String, BillingParty> billingPartyMap = new HashMap<String, BillingParty>();

		static {
			for (BillingParty e : EnumSet.allOf(BillingParty.class)) {
				billingPartyMap.put(e.getName(), e);
			}
		}

		private BillingParty(final String name) {
			this.name = name;

		}

		public String getName() {
			return name;
		}

		public static BillingParty getType(final String name) {
			if (billingPartyMap.containsKey(name)) {
				return billingPartyMap.get(name);
			} else {
				return UNKNOWN;
			}
		}
	}

}
