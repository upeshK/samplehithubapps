
package com.ups.ship;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for OnCallType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="OnCallType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="PickupDetails" type="{http://www.ups.com/XMLSchema/XOLTWS/Ship/v1.0}PickupDetailsType"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "OnCallType", propOrder = {
    "pickupDetails"
})
public class OnCallType {

    @XmlElement(name = "PickupDetails", required = true)
    protected PickupDetailsType pickupDetails;

    /**
     * Gets the value of the pickupDetails property.
     * 
     * @return
     *     possible object is
     *     {@link PickupDetailsType }
     *     
     */
    public PickupDetailsType getPickupDetails() {
        return pickupDetails;
    }

    /**
     * Sets the value of the pickupDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link PickupDetailsType }
     *     
     */
    public void setPickupDetails(PickupDetailsType value) {
        this.pickupDetails = value;
    }

}
