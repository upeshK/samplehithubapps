
package com.ups.ship;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PickupDetailsType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PickupDetailsType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="DistrictCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PickupDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="EarliestTimeReady" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="LatestTimeReady" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="SuiteRoomID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FloorID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Location" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ContactInfo" type="{http://www.ups.com/XMLSchema/XOLTWS/Ship/v1.0}ContactInfoType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PickupDetailsType", propOrder = {
    "districtCode",
    "pickupDate",
    "earliestTimeReady",
    "latestTimeReady",
    "suiteRoomID",
    "floorID",
    "location",
    "contactInfo"
})
public class PickupDetailsType {

    @XmlElement(name = "DistrictCode")
    protected String districtCode;
    @XmlElement(name = "PickupDate", required = true)
    protected String pickupDate;
    @XmlElement(name = "EarliestTimeReady", required = true)
    protected String earliestTimeReady;
    @XmlElement(name = "LatestTimeReady", required = true)
    protected String latestTimeReady;
    @XmlElement(name = "SuiteRoomID")
    protected String suiteRoomID;
    @XmlElement(name = "FloorID")
    protected String floorID;
    @XmlElement(name = "Location")
    protected String location;
    @XmlElement(name = "ContactInfo")
    protected ContactInfoType contactInfo;

    /**
     * Gets the value of the districtCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDistrictCode() {
        return districtCode;
    }

    /**
     * Sets the value of the districtCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDistrictCode(String value) {
        this.districtCode = value;
    }

    /**
     * Gets the value of the pickupDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPickupDate() {
        return pickupDate;
    }

    /**
     * Sets the value of the pickupDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPickupDate(String value) {
        this.pickupDate = value;
    }

    /**
     * Gets the value of the earliestTimeReady property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEarliestTimeReady() {
        return earliestTimeReady;
    }

    /**
     * Sets the value of the earliestTimeReady property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEarliestTimeReady(String value) {
        this.earliestTimeReady = value;
    }

    /**
     * Gets the value of the latestTimeReady property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLatestTimeReady() {
        return latestTimeReady;
    }

    /**
     * Sets the value of the latestTimeReady property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLatestTimeReady(String value) {
        this.latestTimeReady = value;
    }

    /**
     * Gets the value of the suiteRoomID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSuiteRoomID() {
        return suiteRoomID;
    }

    /**
     * Sets the value of the suiteRoomID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSuiteRoomID(String value) {
        this.suiteRoomID = value;
    }

    /**
     * Gets the value of the floorID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFloorID() {
        return floorID;
    }

    /**
     * Sets the value of the floorID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFloorID(String value) {
        this.floorID = value;
    }

    /**
     * Gets the value of the location property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocation() {
        return location;
    }

    /**
     * Sets the value of the location property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocation(String value) {
        this.location = value;
    }

    /**
     * Gets the value of the contactInfo property.
     * 
     * @return
     *     possible object is
     *     {@link ContactInfoType }
     *     
     */
    public ContactInfoType getContactInfo() {
        return contactInfo;
    }

    /**
     * Sets the value of the contactInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link ContactInfoType }
     *     
     */
    public void setContactInfo(ContactInfoType value) {
        this.contactInfo = value;
    }

}
