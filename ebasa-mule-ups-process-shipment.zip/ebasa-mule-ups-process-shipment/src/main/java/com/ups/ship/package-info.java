@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.ups.com/XMLSchema/XOLTWS/Ship/v1.0", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.ups.ship;
